﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class asientoContable
    {
        private int idasiento_contable;
        private int cod_asiento;
        private string cod_cuenta_debe;
        private float importe_debe;
        private string cod_cuenta_haber;
        private float importe_haber;
        private int estado;
        private DateTime fecha_del_asiento;
        private int idusuario;
        private int idcatalogo_de_cuentas;
        private string idempresa;

        public int Idasiento_contable { get => idasiento_contable; set => idasiento_contable = value; }
        public int Cod_asiento { get => cod_asiento; set => cod_asiento = value; }
        public string Cod_cuenta_debe { get => cod_cuenta_debe; set => cod_cuenta_debe = value; }
        public float Importe_debe { get => importe_debe; set => importe_debe = value; }
        public string Cod_cuenta_haber { get => cod_cuenta_haber; set => cod_cuenta_haber = value; }
        public float Importe_haber { get => importe_haber; set => importe_haber = value; }
        public int Estado { get => estado; set => estado = value; }
        public DateTime Fecha_del_asiento { get => fecha_del_asiento; set => fecha_del_asiento = value; }
        public int Idusuario { get => idusuario; set => idusuario = value; }
        public int Idcatalogo_de_cuentas { get => idcatalogo_de_cuentas; set => idcatalogo_de_cuentas = value; }
        public string Idempresa { get => idempresa; set => idempresa = value; }

        public asientoContable()
        {
        }
    }
}
