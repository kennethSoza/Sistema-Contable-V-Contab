﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class libroMayor
    {
        private int idlibro_mayor;
        private string mes;
        private float total_debe;
        private float total_haber;
        private int estado;
        private string concepto_mayor;
        private int idasiento_contable;
        private int idperiodo_contable;
        private string idempresa;
        private int idcatalogo_de_cuentas;
        private int idusuario;

        public int Idlibro_mayor { get => idlibro_mayor; set => idlibro_mayor = value; }
        public string Mes { get => mes; set => mes = value; }
        public float Total_debe { get => total_debe; set => total_debe = value; }
        public float Total_haber { get => total_haber; set => total_haber = value; }
        public int Estado { get => estado; set => estado = value; }
        public string Concepto_mayor { get => concepto_mayor; set => concepto_mayor = value; }
        public int Idasiento_contable { get => idasiento_contable; set => idasiento_contable = value; }
        public int Idperiodo_contable { get => idperiodo_contable; set => idperiodo_contable = value; }
        public string Idempresa { get => idempresa; set => idempresa = value; }
        public int Idcatalogo_de_cuentas { get => idcatalogo_de_cuentas; set => idcatalogo_de_cuentas = value; }
        public int Idusuario { get => idusuario; set => idusuario = value; }

        public libroMayor()
        {
        }


    }
}
