﻿using System;
namespace Sistema_Contable_VContab
{
    public partial class gestionDeCatalogoCuenta : Gtk.Window
    {
        public gestionDeCatalogoCuenta() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal ventana =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }
    }
}
