﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class gestionEmpleado : Gtk.Window
    {
        conexion cnx = new conexion();
        public gestionEmpleado() :base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeview();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), typeof(String),
            typeof(String), typeof(String), typeof(String), typeof(String), typeof(String),
            typeof(String), typeof(String));

        //Método para llenar el treeview
        public void fillTreeview()
        {
            Sistema_Contable_VContab.Datos.dtaEmpleado dta = new Sistema_Contable_VContab.Datos.dtaEmpleado();
            List<Sistema_Contable_VContab.Entidades.empleado> lista = new List<Sistema_Contable_VContab.Entidades.empleado>();
            lista = dta.ListarEmpleado();

            foreach(Sistema_Contable_VContab.Entidades.empleado e in lista)
            {
                ls.AppendValues(e.Idempleado.ToString(), e.Cedula.ToString(), e.Nombre_cargo.ToString(),
                    e.Nombre_empleado.ToString(), e.Apellido_empleado.ToString(), e.Telefono_convencional_empleado.ToString(),
                    e.Celular_empleado.ToString(), e.Correo_empleado.ToString(), e.Direccion_empleado.ToString(),
                    e.Sueldo.ToString());
            }

            //Crear modelo
            tvEmpleados.Model = ls;
            tvEmpleados.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvEmpleados.AppendColumn("Cedula", new CellRendererText(), "text", 1);
            tvEmpleados.AppendColumn("Cargo", new CellRendererText(), "text", 2);
            tvEmpleados.AppendColumn("Nombre", new CellRendererText(), "text", 3);
            tvEmpleados.AppendColumn("Apellido", new CellRendererText(), "text", 4);
            tvEmpleados.AppendColumn("Teléfono Convencional", new CellRendererText(), "text", 5);
            tvEmpleados.AppendColumn("Celular", new CellRendererText(), "text", 6);
            tvEmpleados.AppendColumn("Correo", new CellRendererText(), "text", 7);
            tvEmpleados.AppendColumn("Dirección", new CellRendererText(), "text", 8);
            tvEmpleados.AppendColumn("Sueldo", new CellRendererText(), "text", 9);
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }
    }
}
