﻿using System;
namespace Sistema_Contable_VContab
{
    public partial class usuarioRol : Gtk.Window
    {
        public usuarioRol() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }
    }
}
