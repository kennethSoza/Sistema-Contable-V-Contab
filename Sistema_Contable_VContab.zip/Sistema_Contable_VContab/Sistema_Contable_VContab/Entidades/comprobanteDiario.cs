﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class comprobanteDiario
    {
        private int idlibro_diario;
        private DateTime fecha_del_movimiento;
        private string concepto_del_movimiento;
        private float importe_debe;
        private float importe_haber;
        private int estado;
        private int id_asiento_contable;
        private int idusuario;
        private int idempresa;
        private int idcatalogo_de_cuenta;
        private int idperiodo_contable;

        public int Idlibro_diario { get => idlibro_diario; set => idlibro_diario = value; }
        public DateTime Fecha_del_movimiento { get => fecha_del_movimiento; set => fecha_del_movimiento = value; }
        public string Concepto_del_movimiento { get => concepto_del_movimiento; set => concepto_del_movimiento = value; }
        public float Importe_debe { get => importe_debe; set => importe_debe = value; }
        public float Importe_haber { get => importe_haber; set => importe_haber = value; }
        public int Estado { get => estado; set => estado = value; }
        public int Id_asiento_contable { get => id_asiento_contable; set => id_asiento_contable = value; }
        public int Idusuario { get => idusuario; set => idusuario = value; }
        public int Idempresa { get => idempresa; set => idempresa = value; }
        public int Idcatalogo_de_cuenta { get => idcatalogo_de_cuenta; set => idcatalogo_de_cuenta = value; }
        public int Idperiodo_contable { get => idperiodo_contable; set => idperiodo_contable = value; }

        public comprobanteDiario()
        {
        }

    
    }
}
