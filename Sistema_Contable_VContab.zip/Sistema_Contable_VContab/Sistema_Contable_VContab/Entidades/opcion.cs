﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class opcion
    {
        private int idopcion;
        private string nombre_opcion;
        private string formulario_opcion;

        public int Idopcion { get => idopcion; set => idopcion = value; }
        public string Nombre_opcion { get => nombre_opcion; set => nombre_opcion = value; }
        public string Formulario_opcion { get => formulario_opcion; set => formulario_opcion = value; }

        public opcion()
        {
        }

    }
}
