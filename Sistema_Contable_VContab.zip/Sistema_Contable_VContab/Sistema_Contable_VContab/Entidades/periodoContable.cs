﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class periodoContable
    {
        private int idperiodo_contable;
        private DateTime fecha_inicio;
        private DateTime fecha_fin;
        private int estado;
        private string idempresa;
        private string idusuario;

        public int Idperiodo_contable { get => idperiodo_contable; set => idperiodo_contable = value; }
        public DateTime Fecha_inicio { get => fecha_inicio; set => fecha_inicio = value; }
        public DateTime Fecha_fin { get => fecha_fin; set => fecha_fin = value; }
        public int Estado { get => estado; set => estado = value; }
        public string Idempresa { get => idempresa; set => idempresa = value; }
        public string Idusuario { get => idusuario; set => idusuario = value; }

        public periodoContable()
        {
        }
    }
}
