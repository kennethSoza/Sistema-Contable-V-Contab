﻿using System;
using Gtk;

namespace Sistema_Contable_VContab
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Application.Init();
            //MainWindow win = new MainWindow();
            Sistema_Contable_VContab.menuPrincipal win = new Sistema_Contable_VContab.menuPrincipal();
            win.Show();
            Application.Run();
        }
    }
}
