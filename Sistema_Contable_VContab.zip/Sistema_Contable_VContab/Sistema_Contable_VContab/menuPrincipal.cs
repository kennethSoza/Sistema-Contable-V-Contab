﻿using System;
namespace Sistema_Contable_VContab
{
    public partial class menuPrincipal : Gtk.Window
    {
        public menuPrincipal() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
