﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaAsientoContable
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.asientoContable> ListarAsiento()
        {
            List<Sistema_Contable_VContab.Entidades.asientoContable> listaAsiento = new
                List<Sistema_Contable_VContab.Entidades.asientoContable>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from asiento_contable;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while(idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.asientoContable a = new
                        Sistema_Contable_VContab.Entidades.asientoContable()
                    {
                        Idasiento_contable = Convert.ToInt32(idr["idasiento_contable"]),
                        Cod_asiento = Convert.ToInt32(idr["codigo_asiento"]),
                        Cod_cuenta_debe = idr["codigo_cuenta_debe"].ToString(),
                        Importe_debe = Convert.ToDouble(idr["importe_debe"]),
                        Cod_cuenta_haber = idr["codigo_cuenta_debe"].ToString(),
                        Importe_haber = Convert.ToDouble(idr["importe_haber"]),
                        Estado = idr["estado"].ToString(),
                        Fecha_del_asiento = Convert.ToDateTime(idr["fecha_del_asiento"]),
                        Idusuario = Convert.ToInt32(idr["usuario"]),
                        Idcatalogo_de_cuentas = Convert.ToInt32(idr["cuenta"]),
                        Idempresa = Convert.ToInt32(idr["empresa"]),
                        Entrada_comprobante_diario = Convert.ToInt32(idr["entrada_comprobante_diario"])
                    };
                    listaAsiento.Add(a);
                }
                idr.Close();
                return listaAsiento;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaAsiento;
        }


        public dtaAsientoContable()
        {
        }
    }
}
