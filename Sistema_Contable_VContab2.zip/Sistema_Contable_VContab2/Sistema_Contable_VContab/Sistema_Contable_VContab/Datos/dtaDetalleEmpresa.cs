﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;
using Gtk;
namespace Sistema_Contable_VContab.Datos
{
    public class dtaDetalleEmpresa
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.detalleEmpresa> listarEmpresa()
        {
            List<Sistema_Contable_VContab.Entidades.detalleEmpresa> listaEmpresa
                = new List<Sistema_Contable_VContab.Entidades.detalleEmpresa>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from detalle_empresa;");

            try
            {
                conx.Open(); 
                idr = conx.Leer(CommandType.Text, sb.ToString());

                while(idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.detalleEmpresa de = new
                        Sistema_Contable_VContab.Entidades.detalleEmpresa()
                    {
                        Idempresa = Convert.ToInt32(idr["idempresa"]),
                        Nombre_empresa = idr["nombre_empresa"].ToString(),
                        Nombre_comercial = idr["nombre_comercial"].ToString(),
                        Direccion_empresa = idr["direccion_empresa"].ToString(),
                        Departamento_empresa = idr["departamento_empresa"].ToString(),
                        Correo_empresa = idr["correo_empresa"].ToString(),
                        Estado = idr["estado"].ToString()
                    };
                    listaEmpresa.Add(de);
                }
                idr.Close();
                return listaEmpresa;
            }
                catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaEmpresa;
        }

        //Nuevo método para rellenar los comboboxes
        public ListStore listarEmpresaNombreComercialCmb()
        {
            ListStore datosEmpresa = new ListStore(typeof(string), typeof(string));

            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();

            sb.Append("USE SistemaContable;");
            sb.Append("Select * from detalle_empresa;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while (idr.Read())
                {
                    datosEmpresa.AppendValues(idr[0].ToString(),
                    idr[2].ToString());
                }
                idr.Close();
                return datosEmpresa;

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
        }

        public List<Sistema_Contable_VContab.Entidades.detalleEmpresa> 
        listarEmpresaNombre()
        {
            List<Sistema_Contable_VContab.Entidades.detalleEmpresa> listaEmpresaNombre
                = new List<Sistema_Contable_VContab.Entidades.detalleEmpresa>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from detalle_empresa;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());

                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.detalleEmpresa de = new
                        Sistema_Contable_VContab.Entidades.detalleEmpresa()
                    {
                        Nombre_comercial = idr["nombre_comercial"].ToString()
                    };
                    listaEmpresaNombre.Add(de);
                }
                idr.Close();
                return listaEmpresaNombre;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaEmpresaNombre;
        }

        public dtaDetalleEmpresa()
        {
        }
    }
}
