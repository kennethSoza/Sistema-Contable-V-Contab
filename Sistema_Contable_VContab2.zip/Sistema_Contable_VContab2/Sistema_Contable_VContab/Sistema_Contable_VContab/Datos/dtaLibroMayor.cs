﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaLibroMayor
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.libroMayor>
        ListarLibroMayor()
        {
            List<Sistema_Contable_VContab.Entidades.libroMayor> listaLibroMayor 
            = new List<Sistema_Contable_VContab.Entidades.libroMayor>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from libro_mayor;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.libroMayor lm = new
                    Sistema_Contable_VContab.Entidades.libroMayor()
                    {
                        Idlibro_mayor = Convert.ToInt32(idr["idlibro_mayor"]),
                        Mes = idr["mes"].ToString(),
                        Total_debe = Convert.ToDouble(idr["total_debe"]),
                        Total_haber = Convert.ToDouble(idr["total_haber"]),
                        Estado = idr["estado"].ToString(),
                        Concepto_mayor = idr["concepto_mayor"].ToString(),
                        Idasiento_contable = Convert.ToInt32(idr["asiento_contable"]),
                        Idperiodo_contable = idr["periodo_contable"].ToString(),
                        Idempresa = Convert.ToInt32(idr["empresa"]),
                        Idcatalogo_de_cuentas = Convert.ToInt32(idr["cuenta"]),
                        Idusuario = Convert.ToInt32(idr["usuario"])
                    };
                    listaLibroMayor.Add(lm);
                }
                idr.Close();
                return listaLibroMayor;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaLibroMayor;

        }

        public dtaLibroMayor()
        {
        }
    }
}
