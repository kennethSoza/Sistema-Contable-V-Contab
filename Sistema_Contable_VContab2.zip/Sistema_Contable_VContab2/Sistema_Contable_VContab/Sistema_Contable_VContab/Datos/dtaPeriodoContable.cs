﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaPeriodoContable
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.periodoContable>
        ListarPeriodoContable()
        {
            List<Sistema_Contable_VContab.Entidades.periodoContable> 
            listaPeriodoContables = new 
            List<Sistema_Contable_VContab.Entidades.periodoContable>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from periodo_contable;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.periodoContable pc =
                    new Sistema_Contable_VContab.Entidades.periodoContable()
                    {
                          Idperiodo_contable = idr["idperiodo_contable"].ToString(),
                          Fecha_inicio = Convert.ToDateTime(idr["fecha_inicio"]),
                          Fecha_fin = Convert.ToDateTime(idr["fecha_fin"]),
                          Estado = idr["estado"].ToString(),
                          Idempresa = Convert.ToInt32(idr["empresa"]),
                          Idusuario = Convert.ToInt32(idr["usuario"])
                    };
                    listaPeriodoContables.Add(pc);
                }
                idr.Close();
                return listaPeriodoContables;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaPeriodoContables;
        }
        public dtaPeriodoContable()
        {
        }
    }
}
