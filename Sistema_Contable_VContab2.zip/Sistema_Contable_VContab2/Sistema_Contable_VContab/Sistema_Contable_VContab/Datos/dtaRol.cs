﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaRol
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.rol> ListarRol()
        {
            List<Sistema_Contable_VContab.Entidades.rol> listaRol = new
                List<Sistema_Contable_VContab.Entidades.rol>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from rol");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.rol r = new
                        Sistema_Contable_VContab.Entidades.rol()
                    {
                        Idrol = Convert.ToInt32(idr["idrol"]),
                        Nombre_rol = idr["nombre_rol"].ToString(),
                        Estado = idr["estado"].ToString()
                    };
                    listaRol.Add(r);
                }
                idr.Close();
                return listaRol;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaRol;
        }
        public dtaRol()
        {
        }
    }
}
