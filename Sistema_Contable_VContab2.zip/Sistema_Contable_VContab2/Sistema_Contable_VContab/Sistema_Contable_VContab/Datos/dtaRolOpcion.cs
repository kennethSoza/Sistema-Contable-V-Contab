﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaRolOpcion
    {
        conexion conx = new conexion();

        public  List<Sistema_Contable_VContab.Entidades.rolOpcion> listarRolOpcion()
        {
            List<Sistema_Contable_VContab.Entidades.rolOpcion> listaRolOpcion =
                new List<Sistema_Contable_VContab.Entidades.rolOpcion>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from rol_opcion");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());

                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.rolOpcion ro = new
                        Sistema_Contable_VContab.Entidades.rolOpcion()
                    {
                        Idrol_opcion = Convert.ToInt32(idr["idrol_opcion"]),
                        Estado = idr["estado"].ToString(),
                        Fechacreacion = Convert.ToDateTime(idr["fechacreacion"]),
                        Idrol = Convert.ToInt32(idr["rol"]),
                        Idopcion = Convert.ToInt32(idr["opcion"])
                    };
                    listaRolOpcion.Add(ro);
                }
                idr.Close();
                return listaRolOpcion;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaRolOpcion;
        }
        public dtaRolOpcion()
        {
        }
    }
}
