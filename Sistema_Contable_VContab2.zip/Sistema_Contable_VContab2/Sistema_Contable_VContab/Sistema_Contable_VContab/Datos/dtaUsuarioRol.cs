﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaUsuarioRol
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.usuarioRol> 
        ListarUsuarioRol()
        {
            List<Sistema_Contable_VContab.Entidades.usuarioRol> listaUsuarioRol =
            new List<Sistema_Contable_VContab.Entidades.usuarioRol>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from usuario_rol;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.usuarioRol ur = new
                    Sistema_Contable_VContab.Entidades.usuarioRol()
                    {
                        Idsuario_rol = Convert.ToInt32(idr["Idusuario_rol"]),
                        Fechacreacion = Convert.ToDateTime(idr["fechacreacion"]),
                        Idusuario = Convert.ToInt32(idr["usuario"]),
                        Idrol = Convert.ToInt32(idr["rol"]),
                        Estado = idr["estado"].ToString()

                    };
                    listaUsuarioRol.Add(ur);

                }
                idr.Close();
                return listaUsuarioRol;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaUsuarioRol;
        }
        public dtaUsuarioRol()
        {
        }
    }
}
