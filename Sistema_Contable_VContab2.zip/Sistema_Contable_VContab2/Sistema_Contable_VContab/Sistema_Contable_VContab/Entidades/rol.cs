﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class rol
    {
        private int idrol;
        private string nombre_rol;
        private string estado;

        public int Idrol { get => idrol; set => idrol = value; }
        public string Nombre_rol { get => nombre_rol; set => nombre_rol = value; }
        public string Estado { get => estado; set => estado = value; }

        public rol()
        {
        }

    }
}
