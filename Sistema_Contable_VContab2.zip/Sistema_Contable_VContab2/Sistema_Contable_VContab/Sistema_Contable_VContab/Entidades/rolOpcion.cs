﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class rolOpcion
    {
        private int idrol_opcion;
        private string estado;
        private DateTime fechacreacion;
        private int idrol;
        private int idopcion;

        public int Idrol_opcion { get => idrol_opcion; set => idrol_opcion = value; }
        public string Estado { get => estado; set => estado = value; }
        public DateTime Fechacreacion { get => fechacreacion; set => fechacreacion = value; }
        public int Idrol { get => idrol; set => idrol = value; }
        public int Idopcion { get => idopcion; set => idopcion = value; }


        public rolOpcion()
        {
        }

    
    }
}
