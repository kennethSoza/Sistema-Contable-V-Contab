﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class usuario
    {
        private int idusaurio;
        private string nombre_usuario;
        private string contrasenia;
        private DateTime fechacreacion;
        private string estado;
        private string idempleado;
        private int idempresa;

        public int Idusaurio { get => idusaurio; set => idusaurio = value; }
        public string Nombre_usuario { get => nombre_usuario; set => nombre_usuario = value; }
        public string Contrasenia { get => contrasenia; set => contrasenia = value; }
        public DateTime Fechacreacion { get => fechacreacion; set => fechacreacion = value; }
        public string Estado { get => estado; set => estado = value; }
        public string Idempleado { get => idempleado; set => idempleado = value; }
        public int Idempresa { get => idempresa; set => idempresa = value; }

        public usuario()
        {
        }

    }
}
