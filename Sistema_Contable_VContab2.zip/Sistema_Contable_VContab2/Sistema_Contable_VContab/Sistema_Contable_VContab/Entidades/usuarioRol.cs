﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class usuarioRol
    {
        private int idsuario_rol;
        private DateTime fechacreacion;
        private int idusuario;
        private int idrol;
        private string estado;

        public int Idsuario_rol { get => idsuario_rol; set => idsuario_rol = value; }
        public DateTime Fechacreacion { get => fechacreacion; set => fechacreacion = value; }
        public int Idusuario { get => idusuario; set => idusuario = value; }
        public int Idrol { get => idrol; set => idrol = value; }
        public string Estado { get => estado; set => estado = value; }

        public usuarioRol()
        {
        }

    }
}
