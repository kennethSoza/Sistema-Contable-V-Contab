﻿using System;
using Gtk;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Application.Init();
            //MainWindow win = new MainWindow();
            Sistema_Contable_VContab.inicioSesion win = 
                new Sistema_Contable_VContab.inicioSesion();
            win.Show();
            Application.Run();
        }
    }
}
