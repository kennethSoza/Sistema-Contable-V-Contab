﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class gestionMoneda : Gtk.Window
    {
        public gestionMoneda() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), 
            typeof(String), typeof(String), typeof(String), typeof(String), 
            typeof(String));

        //Metodo para llenar el tree view
        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaMoneda dta = new 
            Sistema_Contable_VContab.Datos.dtaMoneda();
            List<Sistema_Contable_VContab.Entidades.moneda> lista = new 
            List<Sistema_Contable_VContab.Entidades.moneda>();
            lista = dta.ListarMoneda();

            foreach (Sistema_Contable_VContab.Entidades.moneda m in lista)
            {
                ls.AppendValues(m.Idmoneda.ToString(),
                    m.Nombre_moneda.ToString(), m.Cod_iso.ToString(),
                    m.Pais.ToString(), m.Tasa_conversion.ToString(),
                    m.Estado.ToString(), m.Idusuario.ToString());
            }

            //Creando el modelo
            tvMoneda.Model = ls;
            tvMoneda.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvMoneda.AppendColumn("Moneda", new CellRendererText(), "text", 1);
            tvMoneda.AppendColumn("Código ISO", new CellRendererText(), "text", 2);
            tvMoneda.AppendColumn("País", new CellRendererText(), "text", 3);
            tvMoneda.AppendColumn("Tasa de Conversión", new CellRendererText(), "text", 4);
            tvMoneda.AppendColumn("Estado", new CellRendererText(), "text", 5);
            tvMoneda.AppendColumn("Usuario", new CellRendererText(), "text", 6);

        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtIdMoneda.Text = "";
            txtCodIso.Text = "";
            txtNombreMoneda.Text = "";
            txtPais.Text = "";
            txtTasaConversion.Text = "";
            Gtk.TreeIter iter;
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);

        }
    }
}
