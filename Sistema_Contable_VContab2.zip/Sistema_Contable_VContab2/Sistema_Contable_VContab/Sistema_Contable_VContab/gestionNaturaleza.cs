﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class gestionNaturaleza : Gtk.Window
    {
        public gestionNaturaleza() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), 
            typeof(String), typeof(String));
        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaNaturaleza dta = new
            Sistema_Contable_VContab.Datos.dtaNaturaleza();
            List<Sistema_Contable_VContab.Entidades.naturaleza> lista =
            new List<Sistema_Contable_VContab.Entidades.naturaleza>();
            lista = dta.ListarNaturaleza();

            foreach (Sistema_Contable_VContab.Entidades.naturaleza n in
            lista)
            {
                ls.AppendValues(n.Ionaturaleza.ToString(),
                    n.Nombre_naturaleza.ToString(),
                    n.Descripcion_naturaleza.ToString(), n.Estado.ToString());
            }
            //Creando Modelo
            tvNaturaleza.Model = ls;
            tvNaturaleza.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvNaturaleza.AppendColumn("Naturaleza", new CellRendererText(), "text", 1);
            tvNaturaleza.AppendColumn("Descripción", new CellRendererText(), "text", 2);
            tvNaturaleza.AppendColumn("Estado", new CellRendererText(), "text", 3);
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal ventana =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtIdNaturaleza.Text = "";
            txtNombre.Text = "";
            txtDescripcion.Text = "";
            Gtk.TreeIter iter;
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);
        }
    }
}
