﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class gestionOpciones : Gtk.Window
    {
        public gestionOpciones() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), 
            typeof(String), typeof(String));

        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaOpcion dta = new 
            Sistema_Contable_VContab.Datos.dtaOpcion();
            List<Sistema_Contable_VContab.Entidades.opcion> lista = new 
            List<Sistema_Contable_VContab.Entidades.opcion>();
            lista = dta.ListarOpcion();

            foreach (Sistema_Contable_VContab.Entidades.opcion o in lista)
            {
                ls.AppendValues(o.Idopcion.ToString(), 
                o.Nombre_opcion.ToString(), o.Formulario_opcion.ToString(),
                o.Estado.ToString());
            }

            tvOpcion.Model = ls;
            tvOpcion.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvOpcion.AppendColumn("Opción", new CellRendererText(), "text", 1);
            tvOpcion.AppendColumn("Formulario", new CellRendererText(), "text", 2);
            tvOpcion.AppendColumn("Estado", new CellRendererText(), "text", 3);
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtIdOpcion.Text = "";
            txtFormulario.Text = "";
            txtNombreOpcion.Text = "";
            Gtk.TreeIter iter;
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);
        }
    }
}
