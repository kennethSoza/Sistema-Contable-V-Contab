﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class gestionamientoRolOpcion : Gtk.Window
    {
        public gestionamientoRolOpcion() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
            fillComboBoxes();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), 
            typeof(String), typeof(String), typeof(String));
        ListStore lsRol = new ListStore(typeof(String));
        ListStore lsOpcion = new ListStore(typeof(String));
        //Metodo para llenar el tree view
        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaRolOpcion dta = new
                Sistema_Contable_VContab.Datos.dtaRolOpcion();
            List<Sistema_Contable_VContab.Entidades.rolOpcion> lista = new
            List<Sistema_Contable_VContab.Entidades.rolOpcion>();
            lista = dta.listarRolOpcion();

            foreach(Sistema_Contable_VContab.Entidades.rolOpcion ro in lista)
            {
                ls.AppendValues(ro.Idrol_opcion.ToString(),
                    ro.Estado.ToString(), ro.Fechacreacion.ToString(),
                    ro.Idrol.ToString(), ro.Idopcion.ToString());
            }

            //Creando el modelo
            tvRolOpcion.Model = ls;
            tvRolOpcion.AppendColumn("Id", new CellRendererText(), "text", 0);
            tvRolOpcion.AppendColumn("Estado", new CellRendererText(), "text", 1);
            tvRolOpcion.AppendColumn("Fecha creación", new CellRendererText(), "text", 2);
            tvRolOpcion.AppendColumn("Rol", new CellRendererText(), "text", 3);
            tvRolOpcion.AppendColumn("Opción", new CellRendererText(), "text", 4);
        }

        public void fillComboBoxes()
        {
            Sistema_Contable_VContab.Datos.dtaRol dta = new
                Sistema_Contable_VContab.Datos.dtaRol();
            List<Sistema_Contable_VContab.Entidades.rol> lista = new
            List<Sistema_Contable_VContab.Entidades.rol>();
            lista = dta.ListarRol();

            foreach (Sistema_Contable_VContab.Entidades.rol r in lista)
            {
                lsRol.AppendValues(r.Nombre_rol.ToString());
            }
            cmbRol.Model = lsRol;

            Sistema_Contable_VContab.Datos.dtaOpcion dta2 = new
                Sistema_Contable_VContab.Datos.dtaOpcion();
            List<Sistema_Contable_VContab.Entidades.opcion> listaOpcion = new
            List<Sistema_Contable_VContab.Entidades.opcion>();
            listaOpcion = dta2.ListarOpcion();

            foreach (Sistema_Contable_VContab.Entidades.opcion o in listaOpcion)
            {
                lsOpcion.AppendValues(o.Formulario_opcion.ToString());
            }
            cmbOpcion.Model = lsOpcion;
        }
        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtIdRolOpcion.Text = "";
            Gtk.TreeIter iter;
            cmbRol.Model.IterNthChild(out iter, -1);
            cmbRol.SetActiveIter(iter);
            cmbOpcion.Model.IterNthChild(out iter, -1);
            cmbOpcion.SetActiveIter(iter);
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);

        }
    }
}
