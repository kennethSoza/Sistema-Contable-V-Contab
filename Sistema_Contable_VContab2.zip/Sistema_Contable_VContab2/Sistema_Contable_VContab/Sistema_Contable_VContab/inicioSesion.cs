﻿using System;
namespace Sistema_Contable_VContab
{
    public partial class inicioSesion : Gtk.Window
    {
        public inicioSesion() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }

        protected void OnBtnAccederClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }
    }
}
