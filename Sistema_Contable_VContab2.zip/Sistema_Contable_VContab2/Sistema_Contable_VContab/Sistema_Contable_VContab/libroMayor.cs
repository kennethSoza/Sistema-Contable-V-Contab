﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class libroMayor : Gtk.Window
    {
        conexion cnx = new conexion();
        public libroMayor() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
            fillComboBoxes();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), typeof(String),
            typeof(String), typeof(String), typeof(String), typeof(String), typeof(String),
            typeof(String), typeof(String), typeof(String));
        ListStore lsCuenta = new ListStore(typeof(String));
        ListStore lsPeriodoContable = new ListStore(typeof(String));
        ListStore lsAsientoContable = new ListStore(typeof(String));
        ListStore lsEmpresa = new ListStore(typeof(String));
        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaLibroMayor dta = 
            new Sistema_Contable_VContab.Datos.dtaLibroMayor();
            List<Sistema_Contable_VContab.Entidades.libroMayor> lista = 
            new List<Sistema_Contable_VContab.Entidades.libroMayor>();
            lista = dta.ListarLibroMayor();

            foreach (Sistema_Contable_VContab.Entidades.libroMayor lm in lista)
            {
                ls.AppendValues(lm.Idlibro_mayor.ToString(), lm.Mes.ToString(),
                    lm.Total_debe.ToString(), lm.Total_haber.ToString(),
                    lm.Estado.ToString(), lm.Concepto_mayor.ToString(),
                    lm.Idasiento_contable.ToString(),
                    lm.Idperiodo_contable.ToString(), lm.Idempresa.ToString(),
                    lm.Idcatalogo_de_cuentas.ToString(),
                    lm.Idusuario.ToString());
            }

            //creando modelo
            tvLibroMayor.Model = ls;
            tvLibroMayor.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvLibroMayor.AppendColumn("Mes", new CellRendererText(), "text", 1);
            tvLibroMayor.AppendColumn("Total debe", new CellRendererText(), "text", 2);
            tvLibroMayor.AppendColumn("Total haber", new CellRendererText(), "text", 3);
            tvLibroMayor.AppendColumn("Estado", new CellRendererText(), "text", 4);
            tvLibroMayor.AppendColumn("Concepto", new CellRendererText(), "text", 5);
            tvLibroMayor.AppendColumn("Asiento Contable", new CellRendererText(), "text", 6);
            tvLibroMayor.AppendColumn("Período Contable", new CellRendererText(), "text", 7);
            tvLibroMayor.AppendColumn("Empresa", new CellRendererText(), "text", 8);
            tvLibroMayor.AppendColumn("Cuenta", new CellRendererText(), "text", 9);
            tvLibroMayor.AppendColumn("Usuario", new CellRendererText(), "text", 10);
        }

        //Metodo para llenar los comboboxes
        public void fillComboBoxes()
        {
            dtaCatalogoCuenta dtr = new dtaCatalogoCuenta();
            List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas> cuentas =
            new List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>();
            cuentas = dtr.ListarNombreCuenta();

            foreach (Sistema_Contable_VContab.Entidades.catalogoDeCuentas nc in
            cuentas)
            {
                lsCuenta.AppendValues(nc.Nombre_cuenta.ToString());
            }
            cmbCuenta.Model = lsCuenta;

            Sistema_Contable_VContab.Datos.dtaPeriodoContable dta = new
                Sistema_Contable_VContab.Datos.dtaPeriodoContable();
            List<Sistema_Contable_VContab.Entidades.periodoContable> lista =
                new List<Sistema_Contable_VContab.Entidades.periodoContable>();
            lista = dta.ListarPeriodoContable();

            foreach (Sistema_Contable_VContab.Entidades.periodoContable pc in
            lista)
            {
                lsPeriodoContable.AppendValues(pc.Idperiodo_contable.ToString());
            }
            cmbPeriodoContable.Model = lsPeriodoContable;

            Sistema_Contable_VContab.Datos.dtaAsientoContable dtac = new
                Sistema_Contable_VContab.Datos.dtaAsientoContable();
            List<Sistema_Contable_VContab.Entidades.asientoContable> asientos =
                new List<Sistema_Contable_VContab.Entidades.asientoContable>();
            asientos = dtac.ListarAsiento();

            foreach(Sistema_Contable_VContab.Entidades.asientoContable ac in
            asientos)
            {
                lsAsientoContable.AppendValues(ac.Cod_asiento.ToString());
            }
            cmbAsiento.Model = lsAsientoContable;

            Sistema_Contable_VContab.Datos.dtaDetalleEmpresa dtr2 =
                new Sistema_Contable_VContab.Datos.dtaDetalleEmpresa();
            List<Sistema_Contable_VContab.Entidades.detalleEmpresa> empresa =
                new List<Sistema_Contable_VContab.Entidades.detalleEmpresa>();
            empresa = dtr2.listarEmpresaNombre();

            foreach (Sistema_Contable_VContab.Entidades.detalleEmpresa de in
            empresa)
            {
                lsEmpresa.AppendValues(de.Nombre_comercial.ToString());
            }
            cmbEmpresa.Model = lsEmpresa;

        }
        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtIdLibroMayor.Text = "";
            txtMes.Text = "";
            txtConcepto.Text = "";
            txtTotalDebe.Text = "";
            txtTotalHaber.Text = "";
            Gtk.TreeIter iter;
            cmbCuenta.Model.IterNthChild(out iter, -1);
            cmbCuenta.SetActiveIter(iter);
            cmbAsiento.Model.IterNthChild(out iter, -1);
            cmbAsiento.SetActiveIter(iter);
            cmbEmpresa.Model.IterNthChild(out iter, -1);
            cmbEmpresa.SetActiveIter(iter);
            cmbPeriodoContable.Model.IterNthChild(out iter, -1);
            cmbPeriodoContable.SetActiveIter(iter);
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);
        }
    }
}
