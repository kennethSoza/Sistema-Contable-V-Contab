﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaAsientoContable
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.asientoContable> ListarAsiento()
        {
            List<Sistema_Contable_VContab.Entidades.asientoContable> listaAsiento = new
                List<Sistema_Contable_VContab.Entidades.asientoContable>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from asiento_contable;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while(idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.asientoContable a = new
                        Sistema_Contable_VContab.Entidades.asientoContable()
                    {
                        Idasiento_contable = Convert.ToInt32(idr["idasiento_contable"]),
                        Cod_asiento =idr["codigo_asiento"].ToString(),
                        Cod_cuenta_debe = idr["codigo_cuenta_debe"].ToString(),
                        Importe_debe = Convert.ToDouble(idr["importe_debe"]),
                        Cod_cuenta_haber = idr["codigo_cuenta_debe"].ToString(),
                        Importe_haber = Convert.ToDouble(idr["importe_haber"]),
                        Estado = idr["estado"].ToString(),
                        Fecha_del_asiento = Convert.ToDateTime(idr["fecha_del_asiento"]),
                        Idusuario = Convert.ToInt32(idr["usuario"]),
                        Idcatalogo_de_cuentas = Convert.ToInt32(idr["cuenta"]),
                        Idempresa = Convert.ToInt32(idr["empresa"].ToString())
                        ,
                        Entrada_comprobante_diario = Convert.ToInt32(idr["entrada_comprobante_diario"])
                    };
                    listaAsiento.Add(a);
                }
                idr.Close();
                return listaAsiento;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaAsiento;
        }

        #region metodos
        public Int32 guardarasiento(Entidades.asientoContable u)
        {
            conexion con = new conexion();
            MySqlCommand sb = new MySqlCommand();
            StringBuilder sbo = new StringBuilder();
            int guardado = 0;
            int x;
            // esto es toda la sintaxis mysql y el error esta en la parte 2
            try
            {


                sbo.Clear();
                sbo.Append("use SistemaContable;");
                //  sb.Append("Insert into asiento_contable");
                //sb.Append("(idusuarios, nombre, apellido, usuario, pwd, idrol)");
                //  sb.Append("VALUES('" + u.Idasiento_contable + "', '" + u.Cod_asiento + "', '" + u.Cod_cuenta_debe + "', " + u.Importe_debe + "', '" + u.Cod_cuenta_haber + "', '" + u.Importe_haber + "', '" + u.Estado+ "', '" + u.Fecha_del_asiento + "', '" + u.Idusuario + "', '" + u. + "', '" +
                //     "'" + u.Username + "', '" + u.Pwd + "','" + u.Idrol + "');");
                sbo.Append("Insert into SistemaContable.asiento_contable");
                sbo.Append("(codigo_asiento, codigo_cuenta_debe, importe_debe, codigo_cuenta_haber,importe_haber, estado, fecha_del_asiento, usuario, cuenta, empresa, entrada_comprobante_diario)");
                sbo.Append("VALUES('" + u.Cod_asiento + "','" + u.Cod_cuenta_debe +
                "','" + u.Importe_debe + "','" + u.Cod_cuenta_haber + "','" + u.Importe_haber + "','" + u.Estado + "',CURDATE() ,'"  + u.Idusuario + "','" + u.Idcatalogo_de_cuentas +
                "','" + u.Idempresa + "','" + u.Entrada_comprobante_diario + "');");
            }
            catch (Exception error)
            {
                Console.WriteLine("1");
            }
            try
            {
                con.Close();
                con.Open();
                x = con.Ejecutar(CommandType.Text, sbo.ToString());


                return x;
            }
            catch (Exception ex)
            {
               // aqui 
                Console.WriteLine("2");
                throw;
            }
            finally
            {
                con.Close();


                #endregion


            }
        }

        #region metodos
        public Int32 modificarasiento(Entidades.asientoContable u)
        {
            conexion con = new conexion();
            MySqlCommand sb = new MySqlCommand();
            StringBuilder sbo = new StringBuilder();
           
            int x;
            // esto es toda la sintaxis mysql y el error esta en la parte 2
            try
            {


                sbo.Clear();
                sbo.Append("use SistemaContable;");
                /* sb.Append("use sakila;");
                 *  sbo.Append("UPDATE asiento_contable set codigo_asiento = '" + u.Cod_asiento + "' ," + " codigo_cuenta_debe ='" + u.Cod_cuenta_debe + "' ," +
                "importe_debe ='" + u.Importe_debe + "' ," + " codigo_cuenta_haber ='" + u.Cod_cuenta_haber + "' ," +
                 "importe_haber ='" + u.Importe_haber + "' ," + " estado ='" + u.Estado +  "',CURDATE() ,'" + "usuario ='" + u.Idusuario + "' ," + "cuenta='" + u.Idcatalogo_de_cuentas + "' ," +
               "empresa ='" + u.Idempresa + "' ," + "entrada_comprobante_diario ='" + u.Entrada_comprobante_diario + 
                "Where idasiento_contable =" + u.Idasiento_contable);               
            sb.Append("UPDATE actor set first_name = '"+a.First_name+"' ," +
                "last_name = '"+a.Last_name+"', last_update=NOW()" +
                "Where actor_id ="+a.Actor_id);
             */
                // sbo.Append("Insert into SistemaContable.asiento_contable");
                //  sbo.Append("(, codigo_cuenta_debe, importe_debe, codigo_cuenta_haber,importe_haber, estado, fecha_del_asiento, usuario, cuenta, empresa, entrada_comprobante_diario)");
              /*  sbo.Append("(codigo_asiento, codigo_cuenta_debe, importe_debe, codigo_cuenta_haber,importe_haber, estado, fecha_del_asiento, usuario, cuenta, empresa, entrada_comprobante_diario)");
                sbo.Append("VALUES('" + u.Cod_asiento + "','" + u.Cod_cuenta_debe +
                "','" + u.Importe_debe + "','" + u.Cod_cuenta_haber + "','" + u.Importe_haber + "','" + u.Estado + "',CURDATE() ,'" + u.Idusuario + "','" + u.Idcatalogo_de_cuentas +
                "','" + u.Idempresa + "','" + u.Entrada_comprobante_diario + "');");*/
            }
            catch (Exception error)
            {
                Console.WriteLine("1");
            }
            try
            {
                con.Close();
                con.Open();
                x = con.Ejecutar(CommandType.Text, sbo.ToString());


                return x;
            }
            catch (Exception ex)
            {
                // aqui 
                Console.WriteLine("2");
                throw;
            }
            finally
            {
                con.Close();


                #endregion


            }
        }

        public dtaAsientoContable()
        {
        }
    }
}
