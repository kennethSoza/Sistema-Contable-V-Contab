﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;
using Gtk;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaCatalogoCuenta
    {
        conexion conx = new conexion();
        public List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas> ListarCuenta()
        {
            List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>
            listaCuentas = new List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from catalogo_de_cuentas where " +
            	"idcatalogo_de_cuentas != 1;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());

                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.catalogoDeCuentas cc =
                    new Sistema_Contable_VContab.Entidades.catalogoDeCuentas()
                    {
                        Id_catalogo_cuenta = Convert.ToInt32(idr["idcatalogo_de_cuentas"]),
                        Numero_cuenta = idr["numero_cuenta"].ToString(),
                        Nombre_cuenta = idr["nombre__cuenta"].ToString(),
                        Descripcion_cuenta = idr["descripcion_cuenta"].ToString(),
                        Estado = idr["estado"].ToString(),
                        Pais = idr["pais"].ToString(),
                        Cuenta_padre = Convert.ToInt32(idr["cuenta_padre"]),
                        Idusuario = Convert.ToInt32(idr["usuario"]),
                        Idnaturaleza = Convert.ToInt32(idr["naturaleza"]),
                        Idempresa = Convert.ToInt32(idr["empresa"])
                    };
                    listaCuentas.Add(cc);
                }
                idr.Close();
                return listaCuentas;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaCuentas;


        }

        //Metodo nuevo para rellenar comboboxes
        public ListStore listarNombreCuentaCmb()
        {
            ListStore datosCuenta = new ListStore(typeof(string), typeof(string));

            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();

            sb.Append("USE SistemaContable;");
            sb.Append("Select * from catalogo_de_cuentas where " +
                "idcatalogo_de_cuentas != 1;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while (idr.Read())
                {
                    datosCuenta.AppendValues(idr[0].ToString(), 
                    idr[2].ToString());
                }
                idr.Close();
                return datosCuenta;

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
        }

        //Metodo para recoger los datos para rellenar el combo box
        public List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>ListarNombreCuenta()
        {
            List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>
            listaNombreCuentas = new List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from catalogo_de_cuentas where " +
            	"idcatalogo_de_cuentas != 1;");
            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());

                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.catalogoDeCuentas cc =
                    new Sistema_Contable_VContab.Entidades.catalogoDeCuentas()
                    {
                        Nombre_cuenta = idr["nombre__cuenta"].ToString(),
                    };
                    listaNombreCuentas.Add(cc);
                }
                idr.Close();
                return listaNombreCuentas;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaNombreCuentas;

        }

        public List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas> 
        ListarCodigoCuenta()
        {
            List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>
            listaNumeroCuentas = new 
            List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from catalogo_de_cuentas where " +
                "idcatalogo_de_cuentas != 1;");
            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());

                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.catalogoDeCuentas cc =
                    new Sistema_Contable_VContab.Entidades.catalogoDeCuentas()
                    {
                        Numero_cuenta = idr["numero_cuenta"].ToString()
                    };
                    listaNumeroCuentas.Add(cc);
                }
                idr.Close();
                return listaNumeroCuentas;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaNumeroCuentas;

        }
        public dtaCatalogoCuenta()
        {
        }
    }
}
