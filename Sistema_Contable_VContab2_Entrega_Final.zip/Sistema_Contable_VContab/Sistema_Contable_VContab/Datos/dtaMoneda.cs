﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaMoneda
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.moneda> ListarMoneda()
        {
            List<Sistema_Contable_VContab.Entidades.moneda> listaMonedas = 
            new List<Sistema_Contable_VContab.Entidades.moneda>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from moneda;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.moneda m = new
                    Sistema_Contable_VContab.Entidades.moneda()
                    {
                        Idmoneda = Convert.ToInt32(idr["idmoneda"]),
                        Nombre_moneda = idr["nombre_moneda"].ToString(),
                        Cod_iso = idr["cod_iso"].ToString(),
                        Pais = idr["pais"].ToString(),
                        Tasa_conversion = Convert.ToDouble(idr["tasa_conversion"]),
                        Estado = idr["estado"].ToString(),
                        Idusuario = Convert.ToInt32(idr["usuario"])
                    };
                    listaMonedas.Add(m);
                }
                idr.Close();
                return listaMonedas;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaMonedas;
        }
        public dtaMoneda()
        {
        }
    }
}
