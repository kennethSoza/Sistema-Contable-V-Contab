﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaNaturaleza
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.naturaleza> ListarNaturaleza()
        {
            List<Sistema_Contable_VContab.Entidades.naturaleza> listaNaturaleza = 
            new List<Sistema_Contable_VContab.Entidades.naturaleza>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from naturaleza");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.naturaleza n = new
                        Sistema_Contable_VContab.Entidades.naturaleza()
                    {
                        Ionaturaleza = Convert.ToInt32(idr["idnaturaleza"]),
                        Nombre_naturaleza = idr["nombre_naturaleza"].ToString(),
                        Descripcion_naturaleza = idr["descripcion_naturaleza"].ToString(),
                        Estado = idr["estado"].ToString()
                    };
                    listaNaturaleza.Add(n);
                }
                idr.Close();
                return listaNaturaleza;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaNaturaleza;
        }
        public dtaNaturaleza()
        {
        }
    }
}
