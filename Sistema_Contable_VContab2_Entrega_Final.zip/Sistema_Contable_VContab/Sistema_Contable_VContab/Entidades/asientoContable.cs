﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class asientoContable
    {
        private int idasiento_contable;
        private string cod_asiento;
        private string cod_cuenta_debe;
        private double importe_debe;
        private string cod_cuenta_haber;
        private double importe_haber;
        private string estado;
        private DateTime fecha_del_asiento;
        private int idusuario;
        private int idcatalogo_de_cuentas;
        private int idempresa;
        private int entrada_comprobante_diario;

        public int Idasiento_contable { get => idasiento_contable; set => idasiento_contable = value; }
        public string Cod_asiento { get => cod_asiento; set => cod_asiento = value; }
        public string Cod_cuenta_debe { get => cod_cuenta_debe; set => cod_cuenta_debe = value; }
        public double Importe_debe { get => importe_debe; set => importe_debe = value; }
        public string Cod_cuenta_haber { get => cod_cuenta_haber; set => cod_cuenta_haber = value; }
        public double Importe_haber { get => importe_haber; set => importe_haber = value; }
        public string Estado { get => estado; set => estado = value; }
        public DateTime Fecha_del_asiento { get => fecha_del_asiento; set => fecha_del_asiento = value; }
        public int Idusuario { get => idusuario; set => idusuario = value; }
        public int Idcatalogo_de_cuentas { get => idcatalogo_de_cuentas; set => idcatalogo_de_cuentas = value; }
        public int Idempresa { get => idempresa; set => idempresa = value; }
        public int Entrada_comprobante_diario { get => entrada_comprobante_diario; set => entrada_comprobante_diario = value; }

        public asientoContable()
        {
        }

       
    }
}
