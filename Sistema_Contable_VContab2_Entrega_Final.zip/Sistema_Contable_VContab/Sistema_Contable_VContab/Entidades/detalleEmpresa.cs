﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class detalleEmpresa
    {
       private int idempresa;
       private string nombre_empresa;
       private string nombre_comercial;
       private string direccion_empresa;
       private string departamento_empresa;
       private string correo_empresa;
       private string estado;

        public int Idempresa { get => idempresa; set => idempresa = value; }
        public string Nombre_empresa { get => nombre_empresa; set => nombre_empresa = value; }
        public string Nombre_comercial { get => nombre_comercial; set => nombre_comercial = value; }
        public string Direccion_empresa { get => direccion_empresa; set => direccion_empresa = value; }
        public string Departamento_empresa { get => departamento_empresa; set => departamento_empresa = value; }
        public string Correo_empresa { get => correo_empresa; set => correo_empresa = value; }
        public string Estado { get => estado; set => estado = value; }

        public detalleEmpresa()
        {
        }

       
    }
}
