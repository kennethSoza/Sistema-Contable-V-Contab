﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class empleado
    {
        private string idempleado;
        private DateTime fecha_ingreso;
        private string cedula;
        private string cargo_empleado;
        private string nombre_empleado;
        private string apellido_empleado;
        private string telefono_convencional_empleado;
        private string celular_empleado;
        private string correo_empleado;
        private string direccion_empleado;
        private string sueldo;
        private string estado;

        public string Idempleado { get => idempleado; set => idempleado = value; }
        public DateTime Fecha_ingreso { get => fecha_ingreso; set => fecha_ingreso = value; }
        public string Cedula { get => cedula; set => cedula = value; }
        public string Cargo_empleado { get => cargo_empleado; set => cargo_empleado = value; }
        public string Nombre_empleado { get => nombre_empleado; set => nombre_empleado = value; }
        public string Apellido_empleado { get => apellido_empleado; set => apellido_empleado = value; }
        public string Telefono_convencional_empleado { get => telefono_convencional_empleado; set => telefono_convencional_empleado = value; }
        public string Celular_empleado { get => celular_empleado; set => celular_empleado = value; }
        public string Correo_empleado { get => correo_empleado; set => correo_empleado = value; }
        public string Direccion_empleado { get => direccion_empleado; set => direccion_empleado = value; }
        public string Sueldo { get => sueldo; set => sueldo = value; }
        public string Estado { get => sueldo; set => sueldo = value; }

        public empleado()
        {
        }

    }
}
