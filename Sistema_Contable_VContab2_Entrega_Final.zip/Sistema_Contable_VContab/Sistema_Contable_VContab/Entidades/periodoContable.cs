﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class periodoContable
    {
        private string idperiodo_contable;
        private DateTime fecha_inicio;
        private DateTime fecha_fin;
        private string estado;
        private int idempresa;
        private int idusuario;

        public string Idperiodo_contable { get => idperiodo_contable; set => idperiodo_contable = value; }
        public DateTime Fecha_inicio { get => fecha_inicio; set => fecha_inicio = value; }
        public DateTime Fecha_fin { get => fecha_fin; set => fecha_fin = value; }
        public string Estado { get => estado; set => estado = value; }
        public int Idempresa { get => idempresa; set => idempresa = value; }
        public int Idusuario { get => idusuario; set => idusuario = value; }

        public periodoContable()
        {
        }
    }
}
