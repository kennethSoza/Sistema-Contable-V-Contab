﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class comprobanteDiario : Gtk.Window
    {
        public comprobanteDiario() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            filltreeview();
            fillComboBoxes();
        }

        ListStore ls = new ListStore(typeof(String), typeof(String), 
            typeof(String), typeof(String), typeof(String), typeof(String), 
            typeof(String), typeof(String), typeof(String), typeof(String));
        ListStore lsPeriodoContable = new ListStore(typeof(String));
        ListStore lsEmpresa = new ListStore(typeof(String), typeof(String));
        ListStore lsCuenta = new ListStore(typeof(String), typeof(String));

        //Metodo para llenar el tree view
        public void filltreeview()
        {
            Sistema_Contable_VContab.Datos.dtaComprobanteDiario dta = new
                Sistema_Contable_VContab.Datos.dtaComprobanteDiario();
            List<Sistema_Contable_VContab.Entidades.comprobanteDiario> lista =
                new List<Sistema_Contable_VContab.Entidades.comprobanteDiario>();
            lista = dta.listarComprobanteDiario();

            foreach(Sistema_Contable_VContab.Entidades.comprobanteDiario c in
            lista)
            {
                ls.AppendValues(c.Idlibro_diario.ToString(), 
                c.Fecha_del_movimiento.ToString(), 
                c.Concepto_del_movimiento.ToString(), c.Importe_debe.ToString(),
                c.Importe_haber.ToString(), c.Estado.ToString(), 
                c.Idusuario.ToString(), c.Idempresa.ToString(), 
                c.Idcatalogo_de_cuenta.ToString(), 
                c.Idperiodo_contable.ToString());
            }

            //creando el modelo
            tvComprobanteDiario.Model = ls;
            tvComprobanteDiario.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvComprobanteDiario.AppendColumn("Fecha del movimiento", new CellRendererText(), "text", 1);
            tvComprobanteDiario.AppendColumn("Concepto", new CellRendererText(), "text", 2);
            tvComprobanteDiario.AppendColumn("Importe debe", new CellRendererText(), "text", 3);
            tvComprobanteDiario.AppendColumn("Importe haber", new CellRendererText(), "text", 4);
            tvComprobanteDiario.AppendColumn("Estado", new CellRendererText(), "text", 5);
            tvComprobanteDiario.AppendColumn("Usuario", new CellRendererText(), "text", 6);
            tvComprobanteDiario.AppendColumn("Empresa", new CellRendererText(), "text", 7);
            tvComprobanteDiario.AppendColumn("Cuenta", new CellRendererText(), "text", 8);
            tvComprobanteDiario.AppendColumn("Periodo contable", new CellRendererText(), "text", 9);
        }

        //Metodo para llenar los comboboxes
        public void fillComboBoxes()
        {
            Sistema_Contable_VContab.Datos.dtaPeriodoContable dta = new
                Sistema_Contable_VContab.Datos.dtaPeriodoContable();
            List<Sistema_Contable_VContab.Entidades.periodoContable> lista =
                new List<Sistema_Contable_VContab.Entidades.periodoContable>();
            lista = dta.ListarPeriodoContable();

            foreach (Sistema_Contable_VContab.Entidades.periodoContable pc in
            lista)
            {
                lsPeriodoContable.AppendValues(pc.Idperiodo_contable.ToString());
            }
            cmbPeriodoContable.Model = lsPeriodoContable;

            dtaDetalleEmpresa dta2 = new dtaDetalleEmpresa();
            lsEmpresa = dta2.listarEmpresaNombreComercialCmb();
            TreeIter iter2;
            if (lsEmpresa.GetIterFirst(out iter2))
            {
                do
                {
                    this.cmbEmpresa.InsertText(Convert.ToInt32(lsEmpresa.GetValue(iter2, 0)),
                        (String)lsEmpresa.GetValue(iter2, 1));
                }
                while (lsEmpresa.IterNext(ref iter2));
            }
            
            dtaCatalogoCuenta dtr = new dtaCatalogoCuenta();
            lsCuenta = dtr.listarNombreCuentaCmb();
            TreeIter iter;
            if(lsCuenta.GetIterFirst(out iter))
            {
                do
                {
                    this.cmbCuentaAfectada.InsertText(Convert.ToInt32(lsCuenta.GetValue(iter, 0)),
                        (String)lsCuenta.GetValue(iter, 1));
                }
                while (lsCuenta.IterNext(ref iter));
            }

        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtIdMovimiento.Text = "";
            txtDebe.Text = "";
            txtHaber.Text = "";
            txtConcepto.Text = "";
            Gtk.TreeIter iter;
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);
            cmbEmpresa.Model.IterNthChild(out iter, -1);
            cmbEmpresa.SetActiveIter(iter);
            cmbCuentaAfectada.Model.IterNthChild(out iter, -1);
            cmbCuentaAfectada.SetActiveIter(iter);
            cmbPeriodoContable.Model.IterNthChild(out iter, -1);
            cmbPeriodoContable.SetActiveIter(iter);
            DateTime fecha = DateTime.Now;
            jclFechaMovimiento.SelectDay(Convert.ToUInt32(fecha.Day));
            jclFechaMovimiento.SelectMonth(Convert.ToUInt32(fecha.Month-1), 
            Convert.ToUInt32(fecha.Year));
        }

        protected void OnBtnAgregarClicked(object sender, EventArgs e)
        {
            Entidades.comprobanteDiario u = new Entidades.comprobanteDiario();
            // dtaAsientoContable dtr = new dtaAsientoContable();
            dtaComprobanteDiario d = new dtaComprobanteDiario();

            int gu = 0;
            try
            {

               u.Concepto_del_movimiento = this.txtConcepto.Text.ToString();
                u.Importe_debe = int.Parse(this.txtDebe.ToString());
                u.Importe_haber = int.Parse(this.txtHaber.Text.ToString());
                u.Estado =this.cmbEstado.ActiveText.ToString();
                u.Idusuario = 1;
                u.Idempresa = 1;
                u.Idcatalogo_de_cuenta = 1;
                //u.Idperiodo_contable ='1';
                

                    /*
               u.                   

                 private int idlibro_diario;
        private DateTime fecha_del_movimiento;
        private string concepto_del_movimiento;
        private double importe_debe;
        private double importe_haber;
        private string estado;
        private int idusuario;
        private int idempresa;
        private int idcatalogo_de_cuenta;
        private string idperiodo_contable;

                */
                //        DateTime fecha = DateTime.Now;

                //   u.Idasiento_contable = dtr.getIdasiento_contable(int.Parse(this.txtAsiento.Text.ToString()));
                //int
                //  u.Idasiento_contable = int.Parse(this.txtAsiento.Text.ToString());
                //int

                // aqui

                if (gu > 0)
                {
                    Console.WriteLine("Se guardó con exito");
                    filltreeview();
                }
                else
                {
                    Console.WriteLine("3");
                }
            }
            catch (Exception error)
            {
                Console.WriteLine(error);
                Console.WriteLine(error.StackTrace);//Asi ?


            }

            gu = d.guardarcomprobante(u);

            //

            Entidades.asientoContable o= new Entidades.asientoContable();
            dtaAsientoContable dtr = new dtaAsientoContable();

            try
            {


                //        DateTime fecha = DateTime.Now;

                //   u.Idasiento_contable = dtr.getIdasiento_contable(int.Parse(this.txtAsiento.Text.ToString()));
                //int
                //  u.Idasiento_contable = int.Parse(this.txtAsiento.Text.ToString());
             /*   //int
                u.Cod_asiento = this.txtCodigo.Text.ToString();
                //String
                u.Cod_cuenta_debe = this.cmbNumeroCuentaDebe.ActiveText.ToString();
                //double
                u.Importe_debe = double.Parse(this.txtImporteDebe.Text.ToString());
                //String
                u.Cod_cuenta_haber = this.cmbNumeroCuentaHaber.ActiveText.ToString();
                //double
                u.Importe_haber = double.Parse(this.txtImporteHaber.Text.ToString());
                //String


                u.Estado = this.cmbEstado.ActiveText.ToString();
                //datetime
                //  u.Fecha_del_asiento = fecha;
                //int
                u.Idusuario = 1;
                //int el resto
                u.Idcatalogo_de_cuentas = 3;

                u.Idempresa = this.cmbEmpresa.ActiveText.ToString();u.Entrada_comprobante_diario = int.Parse(this.cmbEntradaComprobanteDiario.ActiveText.ToString());

                gu = dtr.guardarasiento(u);

    */

                if (gu > 0)
                {
                    Console.WriteLine("Se guardó con exito");
                    filltreeview();
                }
                else
                {
                    Console.WriteLine("3");
                }
            }
            catch (Exception error)
            {
                Console.WriteLine(error);
                Console.WriteLine(error.StackTrace);//Asi ?


            }


        }

    }
}


