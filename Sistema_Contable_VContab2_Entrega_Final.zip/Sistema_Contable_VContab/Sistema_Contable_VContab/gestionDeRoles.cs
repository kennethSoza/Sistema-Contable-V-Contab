﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class gestionDeRoles : Gtk.Window
    {
        public gestionDeRoles() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), 
        typeof(String));

        //Metodo para llenar el Tree View
        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaRol dta = new
                Sistema_Contable_VContab.Datos.dtaRol();
            List<Sistema_Contable_VContab.Entidades.rol> lista = new
                List<Sistema_Contable_VContab.Entidades.rol>();
            lista = dta.ListarRol();

            foreach(Sistema_Contable_VContab.Entidades.rol r in lista)
            {
                ls.AppendValues(r.Idrol.ToString(), r.Nombre_rol.ToString(),
                    r.Estado.ToString());
            }

            //Creando el modelo
            tvRol.Model = ls;
            tvRol.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvRol.AppendColumn("Rol", new CellRendererText(), "text", 1);
            tvRol.AppendColumn("Estado", new CellRendererText(), "text", 2);
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtIdRol.Text = "";
            txtRol.Text = "";
            Gtk.TreeIter iter;
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);

        }
    }
}
