﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class gestionEmpleado : Gtk.Window
    {
        conexion cnx = new conexion();
        public gestionEmpleado() :base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeview();
            fillComboBoxes();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), typeof(String),
            typeof(String), typeof(String), typeof(String), typeof(String), typeof(String),
            typeof(String), typeof(String), typeof(String), typeof(String));
        ListStore lsRol = new ListStore(typeof(String));

        //Método para llenar el treeview
        public void fillTreeview()
        {
            Sistema_Contable_VContab.Datos.dtaEmpleado dta = new Sistema_Contable_VContab.Datos.dtaEmpleado();
            List<Sistema_Contable_VContab.Entidades.empleado> lista = new List<Sistema_Contable_VContab.Entidades.empleado>();
            lista = dta.ListarEmpleado();

            foreach(Sistema_Contable_VContab.Entidades.empleado e in lista)
            {
                ls.AppendValues(e.Idempleado.ToString(), e.Cedula.ToString(), e.Cargo_empleado.ToString(),
                    e.Nombre_empleado.ToString(), e.Apellido_empleado.ToString(), e.Telefono_convencional_empleado.ToString(),
                    e.Celular_empleado.ToString(), e.Correo_empleado.ToString(), e.Direccion_empleado.ToString(),
                    e.Sueldo.ToString(), e.Fecha_ingreso.ToString(), e.Estado.ToString());
            }

            //Crear modelo
            tvEmpleados.Model = ls;
            tvEmpleados.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvEmpleados.AppendColumn("Cedula", new CellRendererText(), "text", 1);
            tvEmpleados.AppendColumn("Cargo", new CellRendererText(), "text", 2);
            tvEmpleados.AppendColumn("Nombre", new CellRendererText(), "text", 3);
            tvEmpleados.AppendColumn("Apellido", new CellRendererText(), "text", 4);
            tvEmpleados.AppendColumn("Teléfono Convencional", new CellRendererText(), "text", 5);
            tvEmpleados.AppendColumn("Celular", new CellRendererText(), "text", 6);
            tvEmpleados.AppendColumn("Correo", new CellRendererText(), "text", 7);
            tvEmpleados.AppendColumn("Dirección", new CellRendererText(), "text", 8);
            tvEmpleados.AppendColumn("Sueldo", new CellRendererText(), "text", 9);
            tvEmpleados.AppendColumn("Fecha ingreso", new CellRendererText(), "text", 10);
            tvEmpleados.AppendColumn("Estado", new CellRendererText(), "text", 11);
        }

        //Rellenando los comboboxes
        protected void fillComboBoxes()
        {
            Sistema_Contable_VContab.Datos.dtaRol dtr = 
                new Sistema_Contable_VContab.Datos.dtaRol();
            List<Sistema_Contable_VContab.Entidades.rol> roles =
                new List<Sistema_Contable_VContab.Entidades.rol>();
            roles = dtr.ListarRol();

            foreach(Sistema_Contable_VContab.Entidades.rol r in
            roles)
            {
                lsRol.AppendValues(r.Nombre_rol.ToString());
            }
            cmbCargo.Model = lsRol;
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtIdEmpleado.Text = "";
            txtCedula.Text = "";
            txtSueldo.Text = "";
            txtDireccion.Text  = "";
            txtTelefonoConv.Text = "";
            txtNombreEmpleado.Text = "";
            txtApellidoEmpleado.Text = "";
            txtCelular.Text = "";
            txtSueldo.Text = "";
            Gtk.TreeIter iter;
            cmbCargo.Model.IterNthChild(out iter, -1);
            cmbCargo.SetActiveIter(iter);
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);

        }
    }
}
