﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class gestionUsuario : Gtk.Window
    {
        public gestionUsuario() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
            fillComboBoxes();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), typeof(String),
            typeof(String), typeof(String), typeof(String), typeof(String));
        ListStore lsEmpleado = new ListStore(typeof(String));
        ListStore lsEmpresa = new ListStore(typeof(String));

        //Metodo para llenar el tree view
        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaUsuario dta = 
            new Sistema_Contable_VContab.Datos.dtaUsuario();
            List<Sistema_Contable_VContab.Entidades.usuario> lista = new 
            List<Sistema_Contable_VContab.Entidades.usuario>();
            lista = dta.ListarUsuario();

            foreach (Sistema_Contable_VContab.Entidades.usuario u in lista)
            {
                ls.AppendValues(u.Idusaurio.ToString(),
                u.Nombre_usuario.ToString(), u.Fechacreacion.ToString(),
                u.Estado.ToString(), u.Idempleado.ToString(),
                u.Idempresa.ToString(), u.Contrasenia.ToString());
            }

            //creando el modelo 
            tvUsuario.Model = ls;
            tvUsuario.AppendColumn("ID", new CellRendererText(),"text",0);
            tvUsuario.AppendColumn("Usuario", new CellRendererText(), "text", 1);
            tvUsuario.AppendColumn("Fecha de creación", new CellRendererText(), "text", 2);
            tvUsuario.AppendColumn("Estado", new CellRendererText(), "text", 3);
            tvUsuario.AppendColumn("Empleado", new CellRendererText(), "text", 4);
            tvUsuario.AppendColumn("Empresa", new CellRendererText(), "text", 5);
        }

        public void fillComboBoxes()
        {
            Sistema_Contable_VContab.Datos.dtaEmpleado dtr =
                new Sistema_Contable_VContab.Datos.dtaEmpleado();
            List<Sistema_Contable_VContab.Entidades.empleado> empleados =
                new List<Sistema_Contable_VContab.Entidades.empleado>();
            empleados = dtr.ListarEmpleado();

            foreach (Sistema_Contable_VContab.Entidades.empleado e in
            empleados)
            {
                lsEmpleado.AppendValues(e.Idempleado.ToString());
            }
            cmbEmpleado.Model = lsEmpleado;

            Sistema_Contable_VContab.Datos.dtaDetalleEmpresa dtr2 =
                new Sistema_Contable_VContab.Datos.dtaDetalleEmpresa();
            List<Sistema_Contable_VContab.Entidades.detalleEmpresa> empresa =
                new List<Sistema_Contable_VContab.Entidades.detalleEmpresa>();
            empresa = dtr2.listarEmpresaNombre();

            foreach (Sistema_Contable_VContab.Entidades.detalleEmpresa de in
            empresa)
            {
                lsEmpresa.AppendValues(de.Nombre_comercial.ToString());
            }
            cmbEmpresa.Model = lsEmpresa;
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtIdUsuario.Text = "";
            txtUsuario.Text = "";
            txtContrasenia.Text = ""; 
            Gtk.TreeIter iter;
            cmbEmpleado.Model.IterNthChild(out iter, -1);
            cmbEmpleado.SetActiveIter(iter);
            cmbEmpresa.Model.IterNthChild(out iter, -1);
            cmbEmpresa.SetActiveIter(iter);
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);
        }
    }
}
