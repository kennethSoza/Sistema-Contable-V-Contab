﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaEmpleado
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.empleado> ListarEmpleado()
        {
            List<Sistema_Contable_VContab.Entidades.empleado> listaEmpleados = new List<Sistema_Contable_VContab.Entidades.empleado>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from empleado;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while(idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.empleado e = new Sistema_Contable_VContab.Entidades.empleado()
                    {
                        Idempleado = idr["idempleado"].ToString(),
                        //Fecha_ingreso = Convert.ToDateTime(idr["fecha_ingreso"]),
                        Cedula = idr["cedula"].ToString(),
                        Nombre_cargo = idr["nombre_cargo"].ToString(),
                        Nombre_empleado = idr["nombre_empleado"].ToString(),
                        Apellido_empleado = idr["apellido_empleado"].ToString(),
                        Telefono_convencional_empleado = idr["telefono_convencional_empleado"].ToString(),
                        Celular_empleado = idr["celular_empleado"].ToString(),
                        Correo_empleado = idr["correo_empleado"].ToString(),
                        Direccion_empleado = idr["direccion_empleado"].ToString(),
                        Sueldo = idr["sueldo"].ToString()
                    };
                    listaEmpleados.Add(e);
                }
                idr.Close();
                return listaEmpleados;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaEmpleados;
        }
        public dtaEmpleado()
        {
        }
    }
}
