﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class catalogoDeCuentas
    {
        private int id_catalogo_cuenta;
        private string numero_cuenta;
        private string nombre_cuenta;
        private string descripcion_cuenta;
        private int estado;
        private string pais;
        private int cuenta_padre;
        private int idusuario;
        private int idnaturaleza;
        private string idempresa;

        public int Id_catalogo_cuenta { get => id_catalogo_cuenta; set => id_catalogo_cuenta = value; }
        public string Numero_cuenta { get => numero_cuenta; set => numero_cuenta = value; }
        public string Nombre_cuenta { get => nombre_cuenta; set => nombre_cuenta = value; }
        public string Descripcion_cuenta { get => descripcion_cuenta; set => descripcion_cuenta = value; }
        public int Estado { get => estado; set => estado = value; }
        public string Pais { get => pais; set => pais = value; }
        public int Cuenta_padre { get => cuenta_padre; set => cuenta_padre = value; }
        public int Idusuario { get => idusuario; set => idusuario = value; }
        public int Idnaturaleza { get => idnaturaleza; set => idnaturaleza = value; }
        public string Idempresa { get => idempresa; set => idempresa = value; }

        public catalogoDeCuentas()
        {
        }

       
    }
}
