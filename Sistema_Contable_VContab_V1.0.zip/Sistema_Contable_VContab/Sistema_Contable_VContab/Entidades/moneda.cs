﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class moneda
    {
        private int idmoneda;
        private string nombre_moneda;
        private string cod_iso;
        private string pais;
        private float tasa_conversion;
        private int estado;
        private int idusuario;

        public int Idmoneda { get => idmoneda; set => idmoneda = value; }
        public string Nombre_moneda { get => nombre_moneda; set => nombre_moneda = value; }
        public string Cod_iso { get => cod_iso; set => cod_iso = value; }
        public string Pais { get => pais; set => pais = value; }
        public float Tasa_conversion { get => tasa_conversion; set => tasa_conversion = value; }
        public int Estado { get => estado; set => estado = value; }
        public int Idusuario { get => idusuario; set => idusuario = value; }

        public moneda()
        {
        }


    }
}
