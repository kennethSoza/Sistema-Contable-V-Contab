﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class naturaleza
    {
        private int ionaturaleza;
        private string nombre_naturaleza;
        private string descripcion_naturaleza;
        private int estado;

        public int Ionaturaleza { get => ionaturaleza; set => ionaturaleza = value; }
        public string Nombre_naturaleza { get => nombre_naturaleza; set => nombre_naturaleza = value; }
        public string Descripcion_naturaleza { get => descripcion_naturaleza; set => descripcion_naturaleza = value; }
        public int Estado { get => estado; set => estado = value; }

        public naturaleza()
        {
        }
       
    }
}
