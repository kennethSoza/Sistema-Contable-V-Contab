﻿using System;
namespace Sistema_Contable_VContab
{
    public partial class gestionDeCatalogoCuenta : Gtk.Window
    {
        public gestionDeCatalogoCuenta() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
