﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaComprobanteDiario
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.comprobanteDiario> 
        listarComprobanteDiario()
        {
            List<Sistema_Contable_VContab.Entidades.comprobanteDiario>
                listaComprobanteDiarios = new
                List<Sistema_Contable_VContab.Entidades.comprobanteDiario>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from comprobante_diario");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());

                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.comprobanteDiario c = new
                        Sistema_Contable_VContab.Entidades.comprobanteDiario()
                    {
                        Idlibro_diario = Convert.ToInt32(idr["idlibro_diario"]),
                        Fecha_del_movimiento = Convert.ToDateTime(idr["fecha_del_movimiento"]),
                        Concepto_del_movimiento = idr["concepto_movimiento"].ToString(),
                        Importe_debe = Convert.ToDouble(idr["importe_debe"]),
                        Importe_haber = Convert.ToDouble(idr["importe_haber"]),
                        Estado = idr["estado"].ToString(),
                        Idusuario = Convert.ToInt32(idr["usuario"]),
                        Idempresa = Convert.ToInt32(idr["empresa"]),
                        Idcatalogo_de_cuenta = Convert.ToInt32(idr["cuenta"]),
                        Idperiodo_contable = idr["periodo_contable"].ToString()
                    };
                    listaComprobanteDiarios.Add(c);
                }
                idr.Close();
                return listaComprobanteDiarios;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaComprobanteDiarios;
        }

        public dtaComprobanteDiario()
        {
        }
    }
}
