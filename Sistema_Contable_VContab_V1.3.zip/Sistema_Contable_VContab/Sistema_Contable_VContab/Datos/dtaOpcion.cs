﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaOpcion
    {
        conexion conx = new conexion(); 
        public List<Sistema_Contable_VContab.Entidades.opcion> ListarOpcion()
        {
            List<Sistema_Contable_VContab.Entidades.opcion>listaOpciones = 
            new List<Sistema_Contable_VContab.Entidades.opcion>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from opcion;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());

                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.opcion o =
                    new Sistema_Contable_VContab.Entidades.opcion()
                    {
                        Idopcion = Convert.ToInt32(idr["idopcion"]),
                        Nombre_opcion = idr["nombre_opcion"].ToString(),
                        Formulario_opcion = idr["formulario_opcion"].ToString(),
                        Estado = idr["estado"].ToString()
                    };
                    listaOpciones.Add(o);
                }
                idr.Close();
                return listaOpciones;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listaOpciones;
        }

        public dtaOpcion()
        {
        }
    }
}
