﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using MySql.Data.MySqlClient;
using Sistema_Contable_VContab.Entidades;
using Sistema_Contable_VContab.Datos;

namespace Sistema_Contable_VContab.Datos
{
    public class dtaUsuario
    {
        conexion conx = new conexion();

        public List<Sistema_Contable_VContab.Entidades.usuario> ListarUsuario()
        {
            List<Sistema_Contable_VContab.Entidades.usuario> listausuarios = 
            new List<Sistema_Contable_VContab.Entidades.usuario>();
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE SistemaContable;");
            sb.Append("Select * from usuario;");

            try
            {
                conx.Open();
                idr = conx.Leer(CommandType.Text, sb.ToString());
                while (idr.Read())
                {
                    Sistema_Contable_VContab.Entidades.usuario u = new
                    Sistema_Contable_VContab.Entidades.usuario()
                    {
                        Idusaurio = Convert.ToInt32(idr["idusuario"]),
                        Nombre_usuario = idr["usuario"].ToString(),
                        Contrasenia = idr["contrasenia"].ToString(),
                        Fechacreacion = Convert.ToDateTime(idr["fechacreacion"]),
                        Estado = idr["estado"].ToString(),
                        Idempleado = idr["empleado"].ToString(),
                        Idempresa = Convert.ToInt32(idr["empresa"])
                    };
                    listausuarios.Add(u);
                }
                idr.Close();
                return listausuarios;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw;
            }
            finally
            {
                conx.Close();
            }
            return listausuarios;   
        }


        public dtaUsuario()
        {
        }
    }
}
