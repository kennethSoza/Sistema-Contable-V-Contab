﻿using System;
namespace Sistema_Contable_VContab.Entidades
{
    public class comprobanteDiario
    {
        private int idlibro_diario;
        private DateTime fecha_del_movimiento;
        private string concepto_del_movimiento;
        private double importe_debe;
        private double importe_haber;
        private string estado;
        private int idusuario;
        private int idempresa;
        private int idcatalogo_de_cuenta;
        private string idperiodo_contable;

        public int Idlibro_diario { get => idlibro_diario; set => idlibro_diario = value; }
        public DateTime Fecha_del_movimiento { get => fecha_del_movimiento; set => fecha_del_movimiento = value; }
        public string Concepto_del_movimiento { get => concepto_del_movimiento; set => concepto_del_movimiento = value; }
        public double Importe_debe { get => importe_debe; set => importe_debe = value; }
        public double Importe_haber { get => importe_haber; set => importe_haber = value; }
        public string Estado { get => estado; set => estado = value; }
        public int Idusuario { get => idusuario; set => idusuario = value; }
        public int Idempresa { get => idempresa; set => idempresa = value; }
        public int Idcatalogo_de_cuenta { get => idcatalogo_de_cuenta; set => idcatalogo_de_cuenta = value; }
        public string Idperiodo_contable { get => idperiodo_contable; set => idperiodo_contable = value; }

        public comprobanteDiario()
        {
        }

    
    }
}
