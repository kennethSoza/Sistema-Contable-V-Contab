﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class asientoContable : Gtk.Window
    {
        conexion cnx = new conexion();
        public asientoContable() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
            fillComboBoxes();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), 
            typeof(String), typeof(String), typeof(String), typeof(String), 
            typeof(String), typeof(String), typeof(String), typeof(String),
            typeof(String), typeof(String));
        ListStore lsNombre = new ListStore(typeof(String));
        ListStore lsNumero = new ListStore(typeof(String));
        ListStore lsNombreEmpresa = new ListStore(typeof(String));
        ListStore lsEntradaComprobanteDiario = new ListStore(typeof(String));

        //Metodo para llenar el treeview
        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaAsientoContable dta = new
                Sistema_Contable_VContab.Datos.dtaAsientoContable();
            List<Sistema_Contable_VContab.Entidades.asientoContable> lista =
                new List<Sistema_Contable_VContab.Entidades.asientoContable>();
            lista = dta.ListarAsiento();

            foreach(Sistema_Contable_VContab.Entidades.asientoContable a in 
            lista)
            {
                ls.AppendValues(a.Idasiento_contable.ToString(),
                    a.Cod_asiento.ToString(), a.Cod_cuenta_debe.ToString(),
                    a.Importe_debe.ToString(), a.Cod_cuenta_haber.ToString(),
                    a.Importe_haber.ToString(), a.Estado.ToString(),
                    a.Fecha_del_asiento.ToString(), a.Idusuario.ToString(),
                    a.Idcatalogo_de_cuentas.ToString(), a.Idempresa.ToString(),
                    a.Entrada_comprobante_diario.ToString());
            }

            //Creando el modelo
            tvAsientoContable.Model = ls;
            tvAsientoContable.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvAsientoContable.AppendColumn("Codigo del asiento", new CellRendererText(), "text", 1);
            tvAsientoContable.AppendColumn("Código cuenta debe", new CellRendererText(), "text", 2);
            tvAsientoContable.AppendColumn("Importe debe", new CellRendererText(), "text", 3);
            tvAsientoContable.AppendColumn("Código cuenta haber", new CellRendererText(), "text", 4);
            tvAsientoContable.AppendColumn("Importe haber", new CellRendererText(), "text", 5);
            tvAsientoContable.AppendColumn("Estado", new CellRendererText(), "text", 6);
            tvAsientoContable.AppendColumn("Fecha del asiento", new CellRendererText(), "text", 7);
            tvAsientoContable.AppendColumn("Usuario", new CellRendererText(), "text", 8);
            tvAsientoContable.AppendColumn("Cuenta", new CellRendererText(), "text", 9);
            tvAsientoContable.AppendColumn("Empresa", new CellRendererText(), "text", 10);
            tvAsientoContable.AppendColumn("Entrada comprobante diario", new CellRendererText(), "text", 11);

        }

        //Metodos para llenar los comboBox
        public void fillComboBoxes()
        {
            dtaCatalogoCuenta dtr = new dtaCatalogoCuenta();
            List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas> cuentas =
            new List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>();
            cuentas = dtr.ListarNombreCuenta();
           
            foreach(Sistema_Contable_VContab.Entidades.catalogoDeCuentas nc in
            cuentas)
            {
                lsNombre.AppendValues(nc.Nombre_cuenta.ToString());

            }
            cmbCuenta.Model = lsNombre;
           
            dtaCatalogoCuenta dtr2 = new dtaCatalogoCuenta();
            List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas> 
                NumerocuentasDebeHaber = new 
                List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>();
            NumerocuentasDebeHaber = dtr2.ListarCodigoCuenta();

            foreach (Sistema_Contable_VContab.Entidades.catalogoDeCuentas numc in
            NumerocuentasDebeHaber)
            {
                lsNumero.AppendValues(numc.Numero_cuenta.ToString());
            }
            cmbNumeroCuentaDebe.Model = lsNumero;
            cmbNumeroCuentaHaber.Model = lsNumero;


            dtaDetalleEmpresa dtr3 = new dtaDetalleEmpresa();
            List<Sistema_Contable_VContab.Entidades.detalleEmpresa>
                listarNombreEmpresa = new
                List<Sistema_Contable_VContab.Entidades.detalleEmpresa>();
            listarNombreEmpresa = dtr3.listarEmpresaNombre();


            foreach(Sistema_Contable_VContab.Entidades.detalleEmpresa den in
            listarNombreEmpresa)
            {
                lsNombreEmpresa.AppendValues(den.Nombre_comercial.ToString());

            }
            cmbEmpresa.Model = lsNombreEmpresa;

            dtaComprobanteDiario dtr4 = new dtaComprobanteDiario();
            List<Sistema_Contable_VContab.Entidades.comprobanteDiario>
                listarEntradaComprobante = new
                List<Sistema_Contable_VContab.Entidades.comprobanteDiario>();
            listarEntradaComprobante = dtr4.listarComprobanteDiario();


            foreach (Sistema_Contable_VContab.Entidades.comprobanteDiario cd in
            listarEntradaComprobante)
            {
                lsEntradaComprobanteDiario.AppendValues(cd.Idlibro_diario.ToString());

            }
            cmbEntradaComprobanteDiario.Model = lsEntradaComprobanteDiario;
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtAsiento.Text = "";
            txtCodigo.Text = "";
            txtImporteDebe.Text = "";
            txtImporteHaber.Text = "";
            Gtk.TreeIter iter;
            cmbCuenta.Model.IterNthChild(out iter, -1);
            cmbCuenta.SetActiveIter(iter);
            cmbNumeroCuentaDebe.Model.IterNthChild(out iter, -1);
            cmbNumeroCuentaHaber.Model.IterNthChild(out iter, -1);
            cmbNumeroCuentaDebe.SetActiveIter(iter);
            cmbNumeroCuentaHaber.SetActiveIter(iter);
            cmbEmpresa.Model.IterNthChild(out iter, -1);
            cmbEmpresa.SetActiveIter(iter);
            cmbEntradaComprobanteDiario.Model.IterNthChild(out iter, -1);
            cmbEntradaComprobanteDiario.SetActiveIter(iter);
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);

        }
    }
}
