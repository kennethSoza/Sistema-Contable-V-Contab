﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class edicionEmpresaSucursal : Gtk.Window
    {
        public edicionEmpresaSucursal() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
        }   
        ListStore ls = new ListStore(typeof(String), typeof(String), 
            typeof(String), typeof(String), typeof(String), typeof(String), 
            typeof(String));

        //Metodo para llenar el treeview
        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaDetalleEmpresa dta = new
                Sistema_Contable_VContab.Datos.dtaDetalleEmpresa();
            List<Sistema_Contable_VContab.Entidades.detalleEmpresa> lista = new
                List<Sistema_Contable_VContab.Entidades.detalleEmpresa>();
            lista = dta.listarEmpresa();

            foreach(Sistema_Contable_VContab.Entidades.detalleEmpresa de in
            lista)
            {
                ls.AppendValues(de.Idempresa.ToString(),
                de.Nombre_empresa.ToString(), de.Nombre_comercial.ToString(),
                de.Direccion_empresa.ToString(),
                de.Departamento_empresa.ToString(),
                de.Correo_empresa.ToString(), de.Estado.ToString());
            }

            //creando el modelo
            tvEmpresaSucursal.Model = ls;
            tvEmpresaSucursal.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvEmpresaSucursal.AppendColumn("Nombre de la empresa", new CellRendererText(), "text", 1);
            tvEmpresaSucursal.AppendColumn("Nombre comercial", new CellRendererText(), "text", 2);
            tvEmpresaSucursal.AppendColumn("Dirección", new CellRendererText(), "text", 3);
            tvEmpresaSucursal.AppendColumn("Departamento", new CellRendererText(), "text", 4);
            tvEmpresaSucursal.AppendColumn("Correo", new CellRendererText(), "text", 5);
            tvEmpresaSucursal.AppendColumn("Estado", new CellRendererText(), "text", 6);
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }
    }
}
