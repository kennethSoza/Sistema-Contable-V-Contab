﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class gestionDeCatalogoCuenta : Gtk.Window
    {
        public gestionDeCatalogoCuenta() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
            fillComboBoxes();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), typeof(String),
            typeof(String), typeof(String), typeof(String), typeof(String), typeof(String),
            typeof(String), typeof(String));
        ListStore lsCuentaPadre = new ListStore(typeof(String));
        ListStore lsNaturaleza = new ListStore(typeof(String));
        ListStore lsEmpresa = new ListStore(typeof(String));
        //Metodo para llenar el Tree view
        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaCatalogoCuenta dta = new 
            Sistema_Contable_VContab.Datos.dtaCatalogoCuenta();
            List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas> lista = 
            new List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>();
            lista = dta.ListarCuenta();

            foreach(Sistema_Contable_VContab.Entidades.catalogoDeCuentas cc in
            lista)
            {
                ls.AppendValues(cc.Id_catalogo_cuenta.ToString(),
                cc.Numero_cuenta.ToString(), cc.Nombre_cuenta.ToString(),
                cc.Descripcion_cuenta.ToString(), cc.Estado.ToString(),
                cc.Pais.ToString(), cc.Cuenta_padre.ToString(),
                cc.Idusuario.ToString(), cc.Idnaturaleza.ToString(),
                cc.Idempresa.ToString());
            }
            //creando el modelo
            tvCatalogoCuenta.Model = ls;
            tvCatalogoCuenta.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvCatalogoCuenta.AppendColumn("Número de cuenta", new CellRendererText(), "text", 1);
            tvCatalogoCuenta.AppendColumn("Nombre de la cuenta", new CellRendererText(), "text", 2);
            tvCatalogoCuenta.AppendColumn("Descripción", new CellRendererText(), "text", 3);
            tvCatalogoCuenta.AppendColumn("Estado", new CellRendererText(), "text", 4);
            tvCatalogoCuenta.AppendColumn("País", new CellRendererText(), "text", 5);
            tvCatalogoCuenta.AppendColumn("Cuenta padre", new CellRendererText(), "text", 6);
            tvCatalogoCuenta.AppendColumn("Usuario", new CellRendererText(), "text", 7);
            tvCatalogoCuenta.AppendColumn("Naturaleza", new CellRendererText(), "text", 8);
            tvCatalogoCuenta.AppendColumn("Empresa", new CellRendererText(), "text", 9);
        }

        //Metodo para llenar los comboboxes
        public void fillComboBoxes()
        {
            Sistema_Contable_VContab.Datos.dtaCatalogoCuenta dta = new
            Sistema_Contable_VContab.Datos.dtaCatalogoCuenta();
            List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas> lista =
            new List<Sistema_Contable_VContab.Entidades.catalogoDeCuentas>();
            lista = dta.ListarNombreCuenta();

            foreach (Sistema_Contable_VContab.Entidades.catalogoDeCuentas cc in
            lista)
            {
                lsCuentaPadre.AppendValues(cc.Nombre_cuenta.ToString());
            }
            cmbCuentaPadre.Model = lsCuentaPadre;

            Sistema_Contable_VContab.Datos.dtaNaturaleza dta2 = new
                Sistema_Contable_VContab.Datos.dtaNaturaleza();
            List<Sistema_Contable_VContab.Entidades.naturaleza> 
                listaNaturaleza = new 
                List<Sistema_Contable_VContab.Entidades.naturaleza>();
            listaNaturaleza = dta2.ListarNaturaleza();

            foreach (Sistema_Contable_VContab.Entidades.naturaleza n in
            listaNaturaleza)
            {
                lsNaturaleza.AppendValues(n.Nombre_naturaleza.ToString());
            }
            cmbNaturaleza.Model = lsNaturaleza;

            Sistema_Contable_VContab.Datos.dtaDetalleEmpresa dta3 = new
                Sistema_Contable_VContab.Datos.dtaDetalleEmpresa();
            List<Sistema_Contable_VContab.Entidades.detalleEmpresa>
                listaEmpresa = new
                List<Sistema_Contable_VContab.Entidades.detalleEmpresa>();
            listaEmpresa = dta3.listarEmpresaNombre();

            foreach (Sistema_Contable_VContab.Entidades.detalleEmpresa n in
            listaEmpresa)
            {
                lsEmpresa.AppendValues(n.Nombre_comercial.ToString());
            }
            cmbEmpresa.Model = lsEmpresa;
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal ventana =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtIdCuenta.Text = "";
            txtNombreCuenta.Text = "";
            txtNumeroCuenta.Text = "";
            txtDescripción.Text = "";
            txtPais.Text = "";
            Gtk.TreeIter iter;
            cmbEmpresa.Model.IterNthChild(out iter, -1);
            cmbEmpresa.SetActiveIter(iter);
            cmbNaturaleza.Model.IterNthChild(out iter, -1);
            cmbNaturaleza.SetActiveIter(iter);
            cmbCuentaPadre.Model.IterNthChild(out iter, -1);
            cmbCuentaPadre.SetActiveIter(iter);
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);

        }
    }
}
