﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class gestionPeriodoContable : Gtk.Window
    {
        conexion cnx = new conexion();
        public gestionPeriodoContable() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
            fillComboBox();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), 
            typeof(String), typeof(String), typeof(String), typeof(String));
        ListStore lsEmpresa = new ListStore(typeof(String));

        //Metodo para llenar el TreeView
        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaPeriodoContable dta = new 
            Sistema_Contable_VContab.Datos.dtaPeriodoContable();
            List<Sistema_Contable_VContab.Entidades.periodoContable> lista = new 
            List<Sistema_Contable_VContab.Entidades.periodoContable>();
            lista = dta.ListarPeriodoContable();

            foreach(Sistema_Contable_VContab.Entidades.periodoContable pc 
            in lista)
            {
                ls.AppendValues(pc.Idperiodo_contable.ToString(), 
                pc.Fecha_inicio.ToString(), pc.Fecha_fin.ToString(), 
                pc.Estado.ToString(), pc.Idempresa.ToString(), 
                pc.Idusuario.ToString());
            }
            //Creando el modelo
            tvPeriodoContable.Model = ls;
            tvPeriodoContable.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvPeriodoContable.AppendColumn("Fecha de inicio", new CellRendererText(), "text", 1);
            tvPeriodoContable.AppendColumn("Fecha Fin", new CellRendererText(), "text", 2);
            tvPeriodoContable.AppendColumn("Estado", new CellRendererText(), "text", 3);
            tvPeriodoContable.AppendColumn("Empresa", new CellRendererText(), "text", 4);
            tvPeriodoContable.AppendColumn("Usuario", new CellRendererText(), "text", 5);
        }

        public void fillComboBox()
        {
            Sistema_Contable_VContab.Datos.dtaDetalleEmpresa dtr =
                new Sistema_Contable_VContab.Datos.dtaDetalleEmpresa();
            List<Sistema_Contable_VContab.Entidades.detalleEmpresa> empresa =
                new List<Sistema_Contable_VContab.Entidades.detalleEmpresa>();
            empresa = dtr.listarEmpresaNombre();

            foreach (Sistema_Contable_VContab.Entidades.detalleEmpresa de in
            empresa)
            {
                lsEmpresa.AppendValues(de.Nombre_comercial.ToString());
            }
            cmbEmpresa.Model = lsEmpresa;
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNuevoClicked(object sender, EventArgs e)
        {
            txtIdPeriodo.Text = "";
            Gtk.TreeIter iter;
            cmbEmpresa.Model.IterNthChild(out iter, -1);
            cmbEmpresa.SetActiveIter(iter);
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);
            DateTime fecha = DateTime.Now;
            jclFechaInicio.SelectDay(Convert.ToUInt32(fecha.Day));
            jclFechaInicio.SelectMonth(Convert.ToUInt32(fecha.Month - 1),
            Convert.ToUInt32(fecha.Year));
            jclFechaFin.SelectDay(Convert.ToUInt32(fecha.Day));
            jclFechaFin.SelectMonth(Convert.ToUInt32(fecha.Month - 1),
            Convert.ToUInt32(fecha.Year));
        }
    }
}
