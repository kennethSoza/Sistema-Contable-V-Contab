﻿using System;
namespace Sistema_Contable_VContab
{
    public partial class menuPrincipal : Gtk.Window
    {
        public menuPrincipal() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }

        protected void OnBtnGestionCuentasClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.gestionDeCatalogoCuenta ventana =
                new Sistema_Contable_VContab.gestionDeCatalogoCuenta();
            this.Destroy();
        }

        protected void OnBtnGestionPeriodoContableClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.gestionPeriodoContable ventana =
                new Sistema_Contable_VContab.gestionPeriodoContable();
            this.Destroy();
        }

        protected void OnBtnGestionComprobanteDiarioClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.comprobanteDiario ventana =
                new Sistema_Contable_VContab.comprobanteDiario();
            this.Destroy();
        }

        protected void OnBtnGestionLibroMayorClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.libroMayor ventana =
                new Sistema_Contable_VContab.libroMayor();
            this.Destroy();
        }

        protected void OnBtnGestionAsientoContableClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.asientoContable ventana =
                new Sistema_Contable_VContab.asientoContable();
            this.Destroy();
        }

        protected void OnBtnGestionEmpleadoClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.gestionEmpleado ventana =
                new Sistema_Contable_VContab.gestionEmpleado();
            this.Destroy();
        }

        protected void OnBtnRegistroEmpresaSucursalClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.crearEmpresaSucursal ventana =
                new Sistema_Contable_VContab.crearEmpresaSucursal();
            this.Destroy();
        }

        protected void OnBtnEdicionEmpresaSucursalClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.edicionEmpresaSucursal ventana =
                new Sistema_Contable_VContab.edicionEmpresaSucursal();
            this.Destroy();
        }

        protected void OnBtnGestiónUsuariosClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.gestionUsuario ventan = new
                Sistema_Contable_VContab.gestionUsuario();
            this.Destroy();
        }

        protected void OnBtnGestionUsuarioRolClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.usuarioRol ventana = new
                Sistema_Contable_VContab.usuarioRol();
            this.Destroy();
        }

        protected void OnBtnGestionMonedaClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.gestionMoneda ventana = new
                Sistema_Contable_VContab.gestionMoneda();
            this.Destroy();
        }

        protected void OnBtnGestionRolesClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.gestionDeRoles ventana = new
                Sistema_Contable_VContab.gestionDeRoles();
            this.Destroy();
        }

        protected void OnBtnGestionOpcionesClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.gestionOpciones ventana = new
                Sistema_Contable_VContab.gestionOpciones();
            this.Destroy();
        }

        protected void OnBtnGestionRolesOpcionesClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.gestionamientoRolOpcion ventana = new
                Sistema_Contable_VContab.gestionamientoRolOpcion();
            this.Destroy();
        }

        protected void OnBtnBalanceComprobacionesClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.balanceComprobaciones ventana = new
                Sistema_Contable_VContab.balanceComprobaciones();
            this.Destroy();
        }

        protected void OnBtnBalanceGeneralClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.balanceGeneral ventana = new
                Sistema_Contable_VContab.balanceGeneral();
            this.Destroy();
        }

        protected void OnBtnNaturalezaClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.gestionNaturaleza ventana = new
                Sistema_Contable_VContab.gestionNaturaleza();
            this.Destroy();
        }
    }
}
