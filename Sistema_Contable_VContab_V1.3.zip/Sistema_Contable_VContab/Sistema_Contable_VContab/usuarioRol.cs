﻿using System;
using System.Collections.Generic;
using Gtk;
using Sistema_Contable_VContab.Datos;
using Sistema_Contable_VContab.Entidades;

namespace Sistema_Contable_VContab
{
    public partial class usuarioRol : Gtk.Window
    {
        public usuarioRol() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            fillTreeView();
            fillComboBoxes();
        }
        ListStore ls = new ListStore(typeof(String), typeof(String), 
            typeof(String),typeof(String), typeof(String));
        ListStore lsUsuario = new ListStore(typeof(String));
        ListStore lsRol = new ListStore(typeof(String));

        //Metodo para llenar el tree view
        public void fillTreeView()
        {
            Sistema_Contable_VContab.Datos.dtaUsuarioRol dta = new 
            Sistema_Contable_VContab.Datos.dtaUsuarioRol();
            List<Sistema_Contable_VContab.Entidades.usuarioRol> lista = new 
            List<Sistema_Contable_VContab.Entidades.usuarioRol>();
            lista = dta.ListarUsuarioRol();

            foreach(Sistema_Contable_VContab.Entidades.usuarioRol ur in lista)
            {
                ls.AppendValues(ur.Idsuario_rol.ToString(),
                    ur.Fechacreacion.ToString(), ur.Idusuario.ToString(),
                    ur.Idrol.ToString(), ur.Estado.ToString());
            }

            //Creando Modelo
            tvUsuarioRol.Model = ls;
            tvUsuarioRol.AppendColumn("ID", new CellRendererText(), "text", 0);
            tvUsuarioRol.AppendColumn("Fecha de creación", new CellRendererText(), "text", 1);
            tvUsuarioRol.AppendColumn("Usuario", new CellRendererText(), "text", 2);
            tvUsuarioRol.AppendColumn("Rol", new CellRendererText(), "text", 3);
            tvUsuarioRol.AppendColumn("Estado", new CellRendererText(), "text", 4);

        }

        //Rellenando los comboboxes
        public void fillComboBoxes()
        {
            Sistema_Contable_VContab.Datos.dtaUsuario dta =
                new Sistema_Contable_VContab.Datos.dtaUsuario();
            List<Sistema_Contable_VContab.Entidades.usuario> usuario =
                new List<Sistema_Contable_VContab.Entidades.usuario>();
            usuario = dta.ListarUsuario();

            foreach (Sistema_Contable_VContab.Entidades.usuario u in
            usuario)
            {
                lsUsuario.AppendValues(u.Nombre_usuario.ToString());
            }
            cmbUsuario.Model = lsUsuario;


            Sistema_Contable_VContab.Datos.dtaRol dtr =
                new Sistema_Contable_VContab.Datos.dtaRol();
            List<Sistema_Contable_VContab.Entidades.rol> rol =
                new List<Sistema_Contable_VContab.Entidades.rol>();
            rol = dtr.ListarRol();

            foreach (Sistema_Contable_VContab.Entidades.rol r in
            rol)
            {
                lsRol.AppendValues(r.Nombre_rol.ToString());
            }
            cmbRol.Model = lsRol;
        }

        protected void OnBtnVolverClicked(object sender, EventArgs e)
        {
            Sistema_Contable_VContab.menuPrincipal win =
                new Sistema_Contable_VContab.menuPrincipal();
            this.Destroy();
        }

        protected void OnBtnNUevoClicked(object sender, EventArgs e)
        {
            txtIdUsuarioRol.Text = "";
            Gtk.TreeIter iter;
            cmbRol.Model.IterNthChild(out iter, -1);
            cmbRol.SetActiveIter(iter);
            cmbUsuario.Model.IterNthChild(out iter, -1);
            cmbUsuario.SetActiveIter(iter);
            cmbEstado.Model.IterNthChild(out iter, -1);
            cmbEstado.SetActiveIter(iter);
        }
    }
}
