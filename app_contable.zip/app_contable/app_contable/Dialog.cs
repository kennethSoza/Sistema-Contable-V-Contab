﻿using System;
namespace app_contable
{
    public partial class Dialog : Gtk.Dialog
    {
        public Dialog()
        {
            this.Build();
        }
    }
}
