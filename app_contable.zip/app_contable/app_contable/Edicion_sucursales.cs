﻿using System;
namespace app_contable
{
    public partial class Edicion_sucursales : Gtk.Window
    {
        public Edicion_sucursales() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
