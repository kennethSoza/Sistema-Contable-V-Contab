﻿using System;
namespace app_contable
{
    public partial class Gestion_moneda : Gtk.Window
    {
        public Gestion_moneda() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
