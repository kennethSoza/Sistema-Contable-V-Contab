﻿using System;
namespace app_contable
{
    public partial class Gestion_usuarios : Gtk.Window
    {
        public Gestion_usuarios() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
