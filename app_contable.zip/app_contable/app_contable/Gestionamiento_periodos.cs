﻿using System;
namespace app_contable
{
    public partial class Gestionamiento_periodos : Gtk.Window
    {
        public Gestionamiento_periodos() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
