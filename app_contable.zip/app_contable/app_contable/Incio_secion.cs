﻿using System;
namespace app_contable
{
    public partial class Incio_secion : Gtk.Window
    {
        public Incio_secion() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }

        protected void OnButton1Clicked(object sender, EventArgs e)
        {
         
        }
    }
}
