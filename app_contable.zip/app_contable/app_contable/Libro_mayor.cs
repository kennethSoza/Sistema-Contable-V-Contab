﻿using System;
namespace app_contable
{
    public partial class Libro_mayor : Gtk.Window
    {
        public Libro_mayor() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
