﻿using System;
namespace app_contable
{
    public partial class Menu_inicio : Gtk.Window
    {
        public Menu_inicio() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
