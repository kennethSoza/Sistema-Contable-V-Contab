﻿using System;
using Gtk;

namespace app_contable
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Application.Init();
            Menu_inicio win = new Menu_inicio();
            win.Show();
            Application.Run();
        }
    }
}
