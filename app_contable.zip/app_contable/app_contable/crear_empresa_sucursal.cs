﻿using System;
namespace app_contable
{
    public partial class crear_empresa_sucursal : Gtk.Window
    {
        public crear_empresa_sucursal() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
